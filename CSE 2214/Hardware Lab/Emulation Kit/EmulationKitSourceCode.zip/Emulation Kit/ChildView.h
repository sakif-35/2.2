
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// ChildView.h : interface of the CChildView class
//


#pragma once

#include "HardwareDeviceDlg.h"
#include "TimerDlgBar.h"
#include "Constants.h"



// CChildView window

class CChildView : public CWnd
{
private:
	bool m_bInitialChecksDone; 
	UINT m_unTimerID;
	UINT m_unTimerInterval;
	bool m_bTimerStarted; 
	
	CHardwareDeviceDlg *m_apDeviceDlg[MAX_NUM_OF_DEVICES];
	unsigned char m_aucEmulatorMemory[MAX_NUM_OF_PORTS];

	char m_strFileName[500];
	CTime m_kTimeFileWasLastRead;

// Construction
public:
	CChildView();
	virtual ~CChildView();
	void SetTimerInterval(UINT unDelay);

// Overrides
protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Generated message map functions
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDevicesDotMatrix();
	afx_msg void OnDevicesSevenSegment();
	afx_msg void OnDevicesASCIILCD();
	afx_msg void OnDevicesLED();
	afx_msg void OnDevicesPushButtons();
	afx_msg void OnDevicesKeyboard();
	afx_msg void OnDevicesSwitches();
	afx_msg void OnDevicesThermometer();
	afx_msg void OnDevicesPressure();
	DECLARE_MESSAGE_MAP()
};

