
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

#include "HardwareDeviceDlg.h"

// SevenSegmentDlg.h : header file
//

// SevenSegmentDisplay
//
// Basic entity for the Seven Segment Display
//
// Each Seven Segment Display is connected to one 8-bit interface regsiter,
// with each bit controlling one LED of the seven segment (bit must be 1 
// for the LED to be ON).


class SevenSegmentDisplay
{
private:
	unsigned char m_ucValue; // the 8 bit value controlling LEDs

	CBitmap	*m_pUp[2];		// 0 = OFF bitmap, 1 = ON bitmap
	CBitmap	*m_pDown[2];	// 0 = OFF bitmap, 1 = ON bitmap
	
	CBitmap	*m_pRight[2];	// 0 = OFF bitmap, 1 = ON bitmap
	CBitmap	*m_pLeft[2];	// 0 = OFF bitmap, 1 = ON bitmap

	CBitmap	*m_pMiddle[2];	// 0 = OFF bitmap, 1 = ON bitmap
	CBitmap	*m_pDot[2];		// 0 = OFF bitmap, 1 = ON bitmap

	CStatic* m_pLEDs[8]; // the 8 LEDs of the Seven Segment Display

public:
	SevenSegmentDisplay(CWnd* pParentWnd, CPoint *pStartingPos);
	~SevenSegmentDisplay();

	void Draw(unsigned char ucValue);
};


// CSevenSegmentDlg dialog
//
// An Output device consisting of eight Seven Matrix displays. Each display 
// consists of eight segments that could be ON (green) or OFF (gray).
//

class CSevenSegmentDlg : public CHardwareDeviceDlg
{
private:
	InterfaceRegister **m_apRegisters; // 8 registers
	SevenSegmentDisplay *m_apDisplays[8];

	CFont *m_pFont;
	CStatic *m_apAddresses[8];
	CStatic *m_pAddressLabel;

	CButton *m_pClearAllBtn;
	CButton *m_pSetAllBtn;

// Dialog Data
	enum { IDC_CLEAR_ALL = 5000,
		   IDC_SET_ALL = 5001};

// Construction
public:
	CSevenSegmentDlg(CWnd* pParent = NULL);   // standard constructor
	~CSevenSegmentDlg();

// Implementation
	virtual void updateGUI();

	afx_msg void OnSetAll();
	afx_msg void OnClearAll();

	DECLARE_MESSAGE_MAP()
};

