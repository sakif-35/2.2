
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

// InterfaceRegister
//
// This class repersents the 8-bit or 16-bit register that 
// lies between the hardware I/O device and the microprocessr.
// The microprocessor writes and reads from this register using
// IN and OUT instruction (using the appropriate port number). 
// The value in the register affects the I/O hardware appropriatly
// as defined by the hardware device itself.
//
// Note: The harware device may actually include more than one of 
//       interface registers if necessary.
//
//
// Supported input/output addresses for the following Interface Registers are:
//     8192 to 12287 (02000h - 02FFFh) -- 4096 I/O byte locations
//
// The total supported input/output addresses are:
//     15 to 65535 (0000Fh - 0FFFFh)


class InterfaceRegister		// 8-bit wide or 16-bit wide register
{

private:
	bool bIsWordRegister;		// 0: Byte register,	1: Word register
	unsigned short int usnPortNum;	// a number in range from 8192 to 12287 
	unsigned short int usnRegisterValue;	// 8-bit or 16-bit register value

public:
	InterfaceRegister(bool ibIsWordRegister, unsigned short int iusnPortNum);
	virtual ~InterfaceRegister();


	inline bool isWordRegister(); 	// 0: Byte register,	1: Word register

	inline unsigned short int getPortNum();
	inline void setPortNum(unsigned short int iusnPortNum);

	inline unsigned short int InterfaceRegister::getValue()
	{
		return usnRegisterValue;
	}

	inline void InterfaceRegister::setValue(unsigned short int iusnNewValue)
	{
		usnRegisterValue = iusnNewValue;
	}
	
	// implement the following based on either Byte or Word register
	bool writeValueToEmulator(unsigned char *pcEmulatorMemory);
	bool readValueFromEmulator(unsigned char *pcEmulatorMemory);

};

