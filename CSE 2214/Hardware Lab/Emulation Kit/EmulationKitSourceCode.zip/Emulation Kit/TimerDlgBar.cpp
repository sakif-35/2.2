// TimerDlgBar.cpp : implementation file
//

#include "stdafx.h"
#include "ChildView.h"
#include "TimerDlgBar.h"
#include "resource.h"

// CTimerDlgBar dialog

IMPLEMENT_DYNAMIC(CTimerDlgBar, CDialogBar)

BEGIN_MESSAGE_MAP(CTimerDlgBar, CDialogBar)
END_MESSAGE_MAP()


CTimerDlgBar::CTimerDlgBar() : CDialogBar()
{
}

CTimerDlgBar::~CTimerDlgBar()
{
}

BOOL CTimerDlgBar::Create(CWnd* pParentWnd, UINT nIDTemplate, UINT nStyle, UINT nID )
{
	BOOL bResult = CDialogBar::Create(pParentWnd, nIDTemplate, nStyle, nID);

	CSliderCtrl* pDelaySlider = (CSliderCtrl*) GetDlgItem(IDC_DELAY_SLIDER);
	ASSERT(pDelaySlider != NULL);

	// positions 1..6 correspond to (10, 100, 200, 300, 400, 500) ms
	// The range of Emu8086 is (0, 1, 100, 200, 300, 400) ms
	pDelaySlider->SetTicFreq(1);
	pDelaySlider->SetLineSize(1);   // Up/Down Arrow Notifications
	pDelaySlider->SetPageSize(-1);   // PgUp/PgDown Notifications
	pDelaySlider->SetRange(1, 6, TRUE ); // min, max range values
	pDelaySlider->SetPos(2); // default value is 100 ms
	return bResult;
}


// CTimerDlgBar message handlers
BOOL CTimerDlgBar::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	if(wParam == IDC_DELAY_SLIDER)
	{
		CSliderCtrl* pDelaySlider = (CSliderCtrl*) GetDlgItem(IDC_DELAY_SLIDER);
		CStatic* pDelayLabel = (CStatic*) GetDlgItem(IDC_DELAY_VALUE);
		CChildView* pChildView = (CChildView*) GetParent();

		ASSERT(pDelaySlider != NULL);
		ASSERT(pDelayLabel != NULL);
		ASSERT(pChildView != NULL);

		int	nPos = pDelaySlider->GetPos();

		switch(nPos)
		{
		case 1:
            pDelayLabel->SetWindowText("10 ms");
			pChildView->SetTimerInterval(10);
			break;
		case 2:
			pDelayLabel->SetWindowText("100 ms");
			pChildView->SetTimerInterval(100);
			break;
		case 3:
			pDelayLabel->SetWindowText("200 ms");
			pChildView->SetTimerInterval(200);
			break;
		case 4:
			pDelayLabel->SetWindowText("300 ms");
			pChildView->SetTimerInterval(300);
			break;
		case 5:
			pDelayLabel->SetWindowText("400 ms");
			pChildView->SetTimerInterval(400);
			break;
		case 6:
			pDelayLabel->SetWindowText("500 ms");
			pChildView->SetTimerInterval(500);
			break;
		default:
			MessageBox("Timer Interval value selected is incorrect", "ERROR");
			break;
		}

	}

	return CWnd::OnNotify(wParam, lParam, pResult);
}


