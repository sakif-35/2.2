
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

#include "HardwareDeviceDlg.h"
#include "resource.h"

// SwitchesDlg.h : header file
//

// CSwitchesDlg dialog
//
// An Input device consisting of 16 numerical keys (0 - F) that
// act as Push Buttons
//
// The keyboard is connected to one 16-bit interface register. 
// The push button "0" affects bit 0 in the inetrface resgiter and
// the push button "1" affects bit 1 in the inetrface resgiter, etc. 
//

class CSwitchesDlg : public CHardwareDeviceDlg
{
private:
	InterfaceRegister *m_pValue;

	CBitmap *m_pSwitchOFF;
	CBitmap *m_pSwitchON;

	CStatic *m_apSwitches[8];

	CFont *m_pFont;
    CStatic *m_pValueLabel;

// Construction
public:
	CSwitchesDlg(CWnd* pParent = NULL);   // standard constructor
	~CSwitchesDlg();

// Implementation
	virtual void updateGUI();

	afx_msg void OnEditLabels();
	afx_msg void OnSwitchPressed();

	DECLARE_MESSAGE_MAP()
};

