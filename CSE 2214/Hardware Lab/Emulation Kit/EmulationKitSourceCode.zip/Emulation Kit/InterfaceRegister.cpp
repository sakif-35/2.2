
// Copyright � 2004 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// InterfaceRegister.cpp: implementation of the InterfaceRegister class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "InterfaceRegister.h"
#include "Constants.h"


// Construction/Destruction
InterfaceRegister::InterfaceRegister(bool ibIsWordRegister, unsigned short int iusnPortNum)
{
bIsWordRegister = ibIsWordRegister;
usnPortNum = iusnPortNum;
usnRegisterValue = 0; // Initial value is zero
}


InterfaceRegister::~InterfaceRegister()
{
}


// Subroutines
inline bool InterfaceRegister::isWordRegister() 	// 0: Byte register,	1: Word register
{
return bIsWordRegister;
}


inline unsigned short int InterfaceRegister::getPortNum()
{
return usnPortNum;
}


void InterfaceRegister::setPortNum(unsigned short int iusnPortNum)
{
usnPortNum = iusnPortNum;
}


bool InterfaceRegister::writeValueToEmulator(unsigned char *pcEmulatorMemory)
{

if(bIsWordRegister)
	{
	unsigned short int oldValue;

	// Convert 2 bytes to a 16 bit word
	oldValue = pcEmulatorMemory[usnPortNum - MIN_IO_ADDRESS + 1]; // most significant
	oldValue = oldValue << 8;
	oldValue = oldValue + pcEmulatorMemory[usnPortNum - MIN_IO_ADDRESS];

	if(oldValue != usnRegisterValue)
		{
		pcEmulatorMemory[usnPortNum - MIN_IO_ADDRESS] = usnRegisterValue & 0x00FF; // least significant
		pcEmulatorMemory[usnPortNum - MIN_IO_ADDRESS + 1] = (usnRegisterValue & 0xFF00) >> 8;
		return 1; // value updated
		}
	else
		return 0; // no need to update value
	}
else
	{
	unsigned char oldValue;

	oldValue = pcEmulatorMemory[usnPortNum - MIN_IO_ADDRESS];

	if(oldValue != usnRegisterValue)
		{
		pcEmulatorMemory[usnPortNum - MIN_IO_ADDRESS] = usnRegisterValue & 0x00FF;
		return 1; // value updated
		}
	else
		return 0; // no need to update value
	}
}


bool InterfaceRegister::readValueFromEmulator(unsigned char *pcEmulatorMemory) 
{

// This function does not update any GUI after reading the new value 
// of the register since it has no control over the hardware device
 
if(bIsWordRegister)
	{
	unsigned short int newValue;

	// Convert 2 bytes to a 16 bit word
	newValue = pcEmulatorMemory[usnPortNum - MIN_IO_ADDRESS + 1];
	newValue = newValue << 8;
	newValue = newValue + pcEmulatorMemory[usnPortNum - MIN_IO_ADDRESS];

	if(newValue != usnRegisterValue)
		{
		usnRegisterValue = newValue;
		return 1; // value updated
		}
	else
		return 0; // no need to update value
	}

else
	{
	unsigned char newValue;

	newValue = pcEmulatorMemory[usnPortNum - MIN_IO_ADDRESS];

	if(newValue != usnRegisterValue)
		{
		usnRegisterValue = newValue;
		return 1; // value updated
		}
	else
		return 0; // no need to update value
	}

}





