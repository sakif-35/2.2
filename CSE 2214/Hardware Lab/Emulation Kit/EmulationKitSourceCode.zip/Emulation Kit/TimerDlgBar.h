#pragma once

// CTimerDlgBar dialog

class CTimerDlgBar : public CDialogBar
{
private:
	DECLARE_DYNAMIC(CTimerDlgBar)

public:
	CTimerDlgBar();   // standard constructor
	virtual ~CTimerDlgBar();
	BOOL Create(CWnd* pParentWnd, UINT nIDTemplate, UINT nStyle, UINT nID);

protected:
	BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	DECLARE_MESSAGE_MAP()
};
