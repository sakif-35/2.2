
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

#include "HardwareDeviceDlg.h"
#include "resource.h"

// ASCIILCDDlg.h : header file
//

// CASCIILCDDlg dialog
//
// This is an LCD display that can display ASCII characters.
// It consits of three lines, each of which can display 16 characters.
// It is connected to an 3*16 = 48 8-bit interface registers, each register
// contains the ASCII code corresponding to one character on the LCD
// display.

class CASCIILCDDlg : public CHardwareDeviceDlg
{
private:
	InterfaceRegister **m_apRegisters; // 48 registers

	CBitmap *m_pLCDBitmap;
	CStatic *m_pLCD;

	CFont *m_pCharFont; // edit static font
	CBrush *m_pBackBrush; // edit background color
	CStatic *m_apChars[48]; // 48 ASCII characters

	CFont *m_pButtonFont; // edit static font
	CButton *m_pClearAllBtn;

//	CFont *m_pPortFont; // display the contents of each register
//	CStatic *m_apPorts[20];

// Construction
public:
	CASCIILCDDlg(CWnd* pParent = NULL);   // standard constructor
	~CASCIILCDDlg();

// Implementation
	virtual void updateGUI();

protected:
// Dialog Data
	enum { IDC_CLEAR_ALL = 5000};

	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor ); // edit static colors
	afx_msg void OnClearAll();

	DECLARE_MESSAGE_MAP()
};

