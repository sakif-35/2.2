
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// SevenSegmentDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SevenSegmentDlg.h"
#include "InterfaceRegister.h"
#include "Constants.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSevenSegmentDlg dialog

BEGIN_MESSAGE_MAP(CSevenSegmentDlg, CDialog)
ON_BN_CLICKED(IDC_CLEAR_ALL, OnClearAll)
ON_BN_CLICKED(IDC_SET_ALL, OnSetAll)
END_MESSAGE_MAP()


CSevenSegmentDlg::CSevenSegmentDlg(CWnd* pParent /*=NULL*/)
	: CHardwareDeviceDlg(pParent, OUTPUT_DEVICE, EIGHT_BIT_REGISTER, SEVEN_SEGMENT_ADDRESS, 8)
{
	char buffer[20];

	m_apRegisters = CHardwareDeviceDlg::getInterfaceRegisters(); // 8 registers
	
	// dialog text
	SetWindowText("Seven Segment Display Output (2030h ... 2037h)");

	// dialog size
	CRect rectWndRect;
	pParent->GetWindowRect(&rectWndRect); // get client window coordinates
	MoveWindow(CRect(rectWndRect.TopLeft() + CPoint(2, 180), CSize(660, 164)), TRUE);  // set dialog size

	// dialog font (to be used in all controls)
	m_pFont = new CFont();
	m_pFont->CreatePointFont(80, "Arial"); // or use "MS Shell Dlg" (80)

	for(int i = 0; i < 8; i++)
	{
		m_apDisplays[i] = new SevenSegmentDisplay(this, &CPoint(20 + i*65, 16));

		sprintf(buffer, "%4.4Xh", SEVEN_SEGMENT_ADDRESS + i);
		m_apAddresses[i] = new CStatic();
		m_apAddresses[i]->Create(buffer, WS_CHILD | WS_VISIBLE,
								 CRect(CPoint(25 + i*65, 101), CSize(65, 14)), this);
		m_apAddresses[i]->SetFont(m_pFont, true);
	}

	m_pAddressLabel = new CStatic();
	m_pAddressLabel->Create("<< I/O Address", WS_CHILD | WS_VISIBLE | SS_CENTER,
							CRect(CPoint(540, 101), CSize(92, 28)), this);
	m_pAddressLabel->SetFont(m_pFont, true);

	// "Clear All" and "Set All" buttons
	m_pClearAllBtn = new CButton();
	m_pClearAllBtn->Create("Clear All", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
						 CRect(CPoint(550, 14), CSize(88, 28)), this, IDC_CLEAR_ALL);
	m_pClearAllBtn->SetFont(m_pFont, true);
	m_pClearAllBtn->SetFocus(); //default button

	m_pSetAllBtn = new CButton();
	m_pSetAllBtn->Create("Set All", WS_CHILD | WS_VISIBLE,
					  CRect(CPoint(550, 46), CSize(88, 28)), this, IDC_SET_ALL);
	m_pSetAllBtn->SetFont(m_pFont, true);
}


CSevenSegmentDlg::~CSevenSegmentDlg()
{
	delete m_pFont;

	for(int i = 0; i < 8; i++)
	{
		delete m_apDisplays[i];
		delete m_apAddresses[i];
	}
	
	delete m_pAddressLabel;

	delete m_pClearAllBtn;
	delete m_pSetAllBtn;
}
							 
// CSevenSegmentDlg message handlers

void CSevenSegmentDlg::OnClearAll()
{
	// this is a special case where we write to an Interface Register 
	// since this is supposed to be an output device
	for(int i = 0; i < 8; i++) // 8 registers
		m_apRegisters[i]->setValue(0);

	RequestInterrupt(); // force sending new values to the Interface Registers

	updateGUI(); // redraw all Seven Segment digits
}


void CSevenSegmentDlg::OnSetAll()
{
	// this is a special case where we write to an Interface Register 
	// since this is supposed to be an output device
	for(int i = 0; i < 8; i++) // 8 registers
		m_apRegisters[i]->setValue(0xFF);

	RequestInterrupt(); // force sending new values to the Interface Registers

	updateGUI(); // redraw all Seven Segment digits
}


void CSevenSegmentDlg::updateGUI()
{
	for(int i = 0; i < 8; i++)
		m_apDisplays[i]->Draw((unsigned char) m_apRegisters[i]->getValue());
}


////////////////////////////////////////////////////////////////////////////
//

SevenSegmentDisplay::SevenSegmentDisplay(CWnd* pParentWnd, CPoint *pStartingPos)
{
	 // initialize all LEDs to OFF
     m_ucValue = 0;

	// prepare bitmaps

	m_pUp[0] = new CBitmap();
	m_pUp[0]->LoadBitmap(IDB_SEVENSEGMENT_HOR_OFF);
	m_pUp[1] = new CBitmap();
	m_pUp[1]->LoadBitmap(IDB_SEVENSEGMENT_UP_ON);

	m_pDown[0] = new CBitmap();
	m_pDown[0]->LoadBitmap(IDB_SEVENSEGMENT_HOR_OFF);
	m_pDown[1] = new CBitmap();
	m_pDown[1]->LoadBitmap(IDB_SEVENSEGMENT_DOWN_ON);
	
	m_pRight[0] = new CBitmap();
	m_pRight[0]->LoadBitmap(IDB_SEVENSEGMENT_VER_OFF);
	m_pRight[1] = new CBitmap();
	m_pRight[1]->LoadBitmap(IDB_SEVENSEGMENT_RIGHT_ON);

	m_pLeft[0] = new CBitmap();
	m_pLeft[0]->LoadBitmap(IDB_SEVENSEGMENT_VER_OFF);
	m_pLeft[1] = new CBitmap();
	m_pLeft[1]->LoadBitmap(IDB_SEVENSEGMENT_LEFT_ON);

	m_pMiddle[0] = new CBitmap();
	m_pMiddle[0]->LoadBitmap(IDB_SEVENSEGMENT_HOR_OFF);
	m_pMiddle[1] = new CBitmap();
	m_pMiddle[1]->LoadBitmap(IDB_SEVENSEGMENT_MIDDLE_ON);

	m_pDot[0] = new CBitmap();
	m_pDot[0]->LoadBitmap(IDB_SEVENSEGMENT_DOT_OFF);
	m_pDot[1] = new CBitmap();
	m_pDot[1]->LoadBitmap(IDB_SEVENSEGMENT_DOT_ON);

	// create the LEDs
	for(int i = 0; i < 8; i++)
		m_pLEDs[i] = new CStatic();
	
	// segment a
	m_pLEDs[0]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_CENTERIMAGE,
						CRect(CPoint(6, 0) + *pStartingPos, CSize(30, 6)), pParentWnd);
	m_pLEDs[0]->SetBitmap((HBITMAP) *m_pUp[0]);

	// segment b
	m_pLEDs[1]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_CENTERIMAGE,
						CRect(CPoint(36, 6) + *pStartingPos, CSize(6, 30)), pParentWnd);
	m_pLEDs[1]->SetBitmap((HBITMAP) *m_pRight[0]);

	// segment c
	m_pLEDs[2]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_CENTERIMAGE,
						CRect(CPoint(36, 40/*42*/) + *pStartingPos, CSize(6, 30)), pParentWnd);
	m_pLEDs[2]->SetBitmap((HBITMAP) *m_pRight[0]);

	// segment d
	m_pLEDs[3]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_CENTERIMAGE,
						CRect(CPoint(6, 70/*72*/) + *pStartingPos, CSize(30, 6)), pParentWnd);
	m_pLEDs[3]->SetBitmap((HBITMAP) *m_pDown[0]);

	// segment e
	m_pLEDs[4]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_CENTERIMAGE,
						CRect(CPoint(0, 40/*42*/) + *pStartingPos, CSize(6, 30)), pParentWnd);
	m_pLEDs[4]->SetBitmap((HBITMAP) *m_pLeft[0]);

	// segment f
	m_pLEDs[5]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_CENTERIMAGE,
						CRect(CPoint(0, 6) + *pStartingPos, CSize(6, 30)), pParentWnd);
	m_pLEDs[5]->SetBitmap((HBITMAP) *m_pLeft[0]);

	// segment g
	m_pLEDs[6]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_CENTERIMAGE,
						CRect(CPoint(6, 35/*36*/) + *pStartingPos, CSize(30, 6)), pParentWnd);
	m_pLEDs[6]->SetBitmap((HBITMAP) *m_pMiddle[0]);

	// segment dot
	m_pLEDs[7]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_CENTERIMAGE,
						CRect(CPoint(46, 72) + *pStartingPos, CSize(6, 6)), pParentWnd);
	m_pLEDs[7]->SetBitmap((HBITMAP) *m_pDot[0]);
}

SevenSegmentDisplay::~SevenSegmentDisplay()
{
	int i;

	for (i = 0; i < 2; i++)
		delete m_pUp[i];

	for (i = 0; i < 2; i++)
		delete m_pDown[i];
	
	for (i = 0; i < 2; i++)
		delete m_pRight[i];

	for (i = 0; i < 2; i++)
		delete m_pLeft[i];

	for (i = 0; i < 2; i++)
		delete m_pMiddle[i];

	for (i = 0; i < 2; i++)
		delete m_pDot[i];

	for (i = 0; i < 8; i++)
		delete m_pLEDs[i];
}



// The bit must be 1 for the LED to be ON.
void SevenSegmentDisplay::Draw(unsigned char ucValue)
{
	if( m_ucValue == ucValue )
		return; // nothing changed

	// set new value of the column and redraw it
	m_ucValue = ucValue;

	// draw the new value

	// segment a
	m_pLEDs[0]->SetBitmap((HBITMAP) *m_pUp[(m_ucValue) & 0x01]);

	// segment b
	m_pLEDs[1]->SetBitmap((HBITMAP) *m_pRight[(m_ucValue >> 1) & 0x01]);

	// segment c
	m_pLEDs[2]->SetBitmap((HBITMAP) *m_pRight[(m_ucValue >> 2) & 0x01]);

	// segment d
	m_pLEDs[3]->SetBitmap((HBITMAP) *m_pDown[(m_ucValue >> 3) & 0x01]);

	// segment e
	m_pLEDs[4]->SetBitmap((HBITMAP) *m_pLeft[(m_ucValue >> 4) & 0x01]);

	// segment f
	m_pLEDs[5]->SetBitmap((HBITMAP) *m_pLeft[(m_ucValue >> 5) & 0x01]);

	// segment g
	m_pLEDs[6]->SetBitmap((HBITMAP) *m_pMiddle[(m_ucValue >> 6) & 0x01]);

	// segment dot
	m_pLEDs[7]->SetBitmap((HBITMAP) *m_pDot[(m_ucValue >> 7) & 0x01]);
}


