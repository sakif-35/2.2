
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

#include "HardwareDeviceDlg.h"

// PressureDlg.h : header file
//

// CPressureDlg dialog
//
// An Input device representing a pressure gauge connected 
// to an 8-bit interface register. 
// The value returned is 0x00 if pressure is 0%, and
// the value returned is 0xC8 if pressure is 100%
//

class CPressureDlg : public CHardwareDeviceDlg
{
private:
	InterfaceRegister *m_pPressureValue;

	CBitmap *m_pGaugeBitmap;
	CStatic *m_pGauge;
	CStatic *m_pBar;

	CSliderCtrl *m_pSlider;

	CFont *m_pFont;
	CStatic *m_pPressureValueLabel;

// Dialog Data
	enum {IDC_PRESSURE_SLIDER = 4000};

// Construction
public:
	CPressureDlg(CWnd* pParent = NULL);   // standard constructor
	~CPressureDlg();

// Implementation
	virtual void updateGUI();
	BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);

	DECLARE_MESSAGE_MAP()
};

