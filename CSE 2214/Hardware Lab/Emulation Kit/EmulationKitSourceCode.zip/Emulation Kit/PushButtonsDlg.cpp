
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// PushButtonsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PushButtonsDlg.h"
#include "InterfaceRegister.h"
#include "Constants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPushButtonsDlg dialog

BEGIN_MESSAGE_MAP(CPushButtonsDlg, CDialog)
ON_BN_CLICKED(IDC_CHANGE_LABELS, OnChangeLabels)
ON_BN_CLICKED(5000, OnKeyPressed)
ON_BN_CLICKED(5001, OnKeyPressed)
ON_BN_CLICKED(5002, OnKeyPressed)
ON_BN_CLICKED(5003, OnKeyPressed)
ON_BN_CLICKED(5004, OnKeyPressed)
ON_BN_CLICKED(5005, OnKeyPressed)
ON_BN_CLICKED(5006, OnKeyPressed)
ON_BN_CLICKED(5007, OnKeyPressed)
ON_BN_CLICKED(5008, OnKeyPressed)
ON_BN_CLICKED(5009, OnKeyPressed)
ON_BN_CLICKED(5010, OnKeyPressed)
ON_BN_CLICKED(5011, OnKeyPressed)
ON_BN_CLICKED(5012, OnKeyPressed)
ON_BN_CLICKED(5013, OnKeyPressed)
ON_BN_CLICKED(5014, OnKeyPressed)
ON_BN_CLICKED(5015, OnKeyPressed)
END_MESSAGE_MAP()


CPushButtonsDlg::CPushButtonsDlg(CWnd* pParent /*=NULL*/)
	: CHardwareDeviceDlg(pParent, INPUT_DEVICE, SIXTEEN_BIT_REGISTER, PUSH_BUTTONS_ADDRESS, 1)
{
	m_pValue = (CHardwareDeviceDlg::getInterfaceRegisters())[0];

	// dialog text
	SetWindowText("Push Buttons Input (2080h)");

	// dialog size
	CRect rectWndRect;
	pParent->GetWindowRect(&rectWndRect); // get client window coordinates
	MoveWindow(CRect(rectWndRect.TopLeft() + CPoint(662, 242), CSize(272, 160)), TRUE);  // set dialog size

	// dialog font (to be used in all controls)
	m_pFont = new CFont();
	m_pFont->CreatePointFont(80, "Arial"); // or use "MS Shell Dlg" (80)

	// first set of labels (initial set)
	char *pcLabels[16] = {"&0", "&1", "&2", "&3", "&4", "&5", "&6", "&7", 
						  "&8", "&9", "&A", "&B", "&C", "&D", "&E", "&F"};

	for(int i = 0; i < 16; i++)
	{
		m_apKeys[i] = new CButton();
		m_apKeys[i]->Create(pcLabels[i], WS_CHILD | WS_VISIBLE | BS_PUSHLIKE,   /*| BS_CHECKBOX | BS_PUSHBUTTON,  */
							CRect(CPoint(12+30*(i%8), 12+30*int(i/8)), CSize(29, 29)), this, 5000+i);
		m_apKeys[i]->SetFont(m_pFont, true);
	}

	nLebelsUsed = 1; // used first set of labels (can be changed)

	m_pValueLabel = new CStatic();
	m_pValueLabel->Create("0000000000000000", WS_CHILD | WS_VISIBLE | SS_CENTER,
							CRect(CPoint(121, 86), CSize(120, 28)), this);
	m_pValueLabel->SetFont(m_pFont, true);

	// "Change Labels" button
	m_pChangeLabelsBtn = new CButton();
	m_pChangeLabelsBtn->Create("New Labels", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
						 CRect(CPoint(12, 82), CSize(88, 28)), this, IDC_CHANGE_LABELS);
	m_pChangeLabelsBtn->SetFont(m_pFont, true);
	m_pChangeLabelsBtn->SetFocus(); //default button

	updateGUI(); // initial values of switches from Emulator I/O file
}


CPushButtonsDlg::~CPushButtonsDlg()
{
	for(int i = 0; i < 16; i++)
		delete m_apKeys[i];

	delete m_pFont;
	delete m_pValueLabel;
	delete m_pChangeLabelsBtn;
}
							 
// CPushButtonsDlg message handlers

void CPushButtonsDlg::OnChangeLabels()
{
	char *pcLabels1[8] = {"&8", "&9", "&A", "&B",  // first set
						  "&C", "&D", "&E", "&F"};
	char *pcLabels2[8] = {"<<", ">>", "<<", ">>",  // second set
						  "<<", ">>", "<<", ">>"};

	if(nLebelsUsed == 1) // go to second set
	{
		for(int i = 8; i < 16; i++) // change only special characters
			m_apKeys[i]->SetWindowText(pcLabels2[i-8]);
		nLebelsUsed = 2;
	}
	else if(nLebelsUsed == 2) // go to first set
	{
		for(int i = 8; i < 16; i++) // change only special characters
			m_apKeys[i]->SetWindowText(pcLabels1[i-8]);
		nLebelsUsed = 1;
	}
}

void CPushButtonsDlg::OnKeyPressed()
{
	const MSG* message = GetCurrentMessage(); 
	char cKeyIndex = char(message->wParam - 5000);
	// message is a button click (message->message == 273)
	// and button ID (message->wParam) is between 5000 and 5023
	
	// remove focus from pressed button (prevents duplicate messages when button changes state)
	m_pValueLabel->SetFocus(); 

	unsigned short int usnValue = m_pValue->getValue();

	if(((usnValue >> cKeyIndex) & 0x0001) == 1)
		usnValue = usnValue ^ (0x0001 << cKeyIndex);
	else
		usnValue = usnValue ^ (0x0001 << cKeyIndex);

	m_pValue->setValue(usnValue); // fill the register
	RequestInterrupt(); // force sending new values to the Interface Registers

	updateGUI();
}


void CPushButtonsDlg::updateGUI()
{
	unsigned short int usnValue = m_pValue->getValue();

	char buffer[20] = "0000000000000000";

	for(int i = 0; i < 16; i++)
		if(((usnValue >> i) & 0x0001) == 1)
		{
			m_apKeys[i]->SetState(true); // release the button
			buffer[15 - i] = '1';
		}
		else
		{
			m_apKeys[i]->SetState(false);	// push the button
			buffer[15 - i] = '0';
		}

	m_pValueLabel->SetWindowText(buffer);
}


