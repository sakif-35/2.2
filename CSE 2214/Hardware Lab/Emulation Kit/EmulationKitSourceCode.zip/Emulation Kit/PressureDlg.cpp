
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// PressureDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PressureDlg.h"
#include "InterfaceRegister.h"
#include "Constants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPressureDlg dialog

BEGIN_MESSAGE_MAP(CPressureDlg, CDialog)
END_MESSAGE_MAP()


CPressureDlg::CPressureDlg(CWnd* pParent /*=NULL*/)
	: CHardwareDeviceDlg(pParent, INPUT_DEVICE, EIGHT_BIT_REGISTER, PRESSURE_ADDRESS, 1)
{
	m_pPressureValue = (CHardwareDeviceDlg::getInterfaceRegisters())[0]; // initial value is zero

	// dialog text
	SetWindowText("Pressure Guage (2088h)");

	// dialog size
	CRect rectWndRect;
	pParent->GetWindowRect(&rectWndRect); // get client window coordinates
	MoveWindow(CRect(rectWndRect.TopLeft() + CPoint(933, 121), CSize(191, 281)), TRUE);  // set dialog size

	// dialog font (to be used in all controls)
	m_pFont = new CFont();
	m_pFont->CreatePointFont(80, "Arial"); // or use "MS Shell Dlg" (80)

	m_pGaugeBitmap = new CBitmap();
	m_pGaugeBitmap->LoadBitmap(IDB_PRESSURE);

	m_pGauge = new CStatic();
	m_pGauge->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP,
				   CRect(CPoint(17,12), CSize(435,173)), this);
	m_pGauge->SetBitmap((HBITMAP) *m_pGaugeBitmap);

	m_pBar = new CStatic();
	m_pBar->Create("", WS_CHILD | WS_VISIBLE | SS_BLACKRECT,
					CRect(CPoint(35, 142), CSize(29, 0)), this);

	// Pressure Level Slider
	m_pSlider = new CSliderCtrl();
	m_pSlider->Create(WS_CHILD | WS_VISIBLE | TBS_VERT | TBS_LEFT | TBS_AUTOTICKS,
					  CRect(CPoint(145, 18), CSize(21, 130)), this, IDC_PRESSURE_SLIDER);
	// position 0 corresponds to 0xC8 and corresponds to 100% 
	// position 100 corresponds to 0x00 and corresponds to 0%
	m_pSlider->SetTicFreq(10);    // Send TBM_SETTICFREQ
	m_pSlider->SetLineSize(10);   // Up/Down Notifications
	m_pSlider->SetPageSize(50);   // PgUp/PgDown Notifications
	m_pSlider->SetRange(0, 100, TRUE ); // min, max range values
	m_pSlider->SetPos(100);
	m_pSlider->SetFocus();

	m_pPressureValueLabel = new CStatic();
	m_pPressureValueLabel->Create("Pressure: 0x00  (0%)", WS_CHILD | WS_VISIBLE | SS_LEFT,
							CRect(CPoint(24, 215), CSize(180, 28)), this);
	m_pPressureValueLabel->SetFont(m_pFont, true);
}


CPressureDlg::~CPressureDlg()
{
	delete m_pGaugeBitmap;
	delete m_pGauge;
	delete m_pBar;

	delete m_pSlider;

	delete m_pFont;
	delete m_pPressureValueLabel;
}
							 
// CPressureDlg message handlers

void CPressureDlg::updateGUI()
{
// do nothing (this is an input device not an output device)
}

BOOL CPressureDlg::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	if(wParam == IDC_PRESSURE_SLIDER)
	{
		int	nPos = m_pSlider->GetPos();

		// adjust mercury bar
		m_pBar->MoveWindow(35, 26 + int(1.16*nPos), 29, int(1.16*(100 - nPos)), TRUE );

		// update pressure reading
		char buffer[40];
		sprintf(buffer, "Pressure: 0x%02X  (%d%%)", (100 - nPos)*2, 100 - nPos);
		m_pPressureValueLabel->SetWindowText(buffer);

		m_pPressureValue->setValue(100 - nPos);

		RequestInterrupt(); // force sending new values to the Interface Registers
	}

	return CWnd::OnNotify(wParam, lParam, pResult);
}

