/*
 Implement external devices for Emu8086 -
 8086 Microprocessor Emulator.

 Supported input/output addresses for the following Interface Registers are:
     8192 to 12287 (02000h - 02FFFh) -- 4096 I/O byte locations

 The total supported input/output addresses are:
     15 to 65535 (0000Fh - 0FFFFh)


 Version 2.12 of Emu8086 or above is required.
*/


