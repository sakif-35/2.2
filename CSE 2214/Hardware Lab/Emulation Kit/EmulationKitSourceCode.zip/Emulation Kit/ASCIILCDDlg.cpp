
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// LEDsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ASCIILCDDlg.h"
#include "InterfaceRegister.h"
#include "Constants.h"
#include "resource.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CASCIILCDDlg dialog

BEGIN_MESSAGE_MAP(CASCIILCDDlg, CDialog)
ON_WM_CTLCOLOR()
ON_BN_CLICKED(IDC_CLEAR_ALL, OnClearAll)
END_MESSAGE_MAP()


CASCIILCDDlg::CASCIILCDDlg(CWnd* pParent /*=NULL*/)
: CHardwareDeviceDlg(pParent, OUTPUT_DEVICE, EIGHT_BIT_REGISTER, ASCII_LCD_ADDRESS, 48) // 48 registers
{
	m_apRegisters = CHardwareDeviceDlg::getInterfaceRegisters(); // initialized to zeros

	// dialog text
	SetWindowText("ASCII LCD Display Output (2040h ... 206Fh)");

	// dialog size
	CRect rectWndRect;
	pParent->GetWindowRect(&rectWndRect); // get client window coordinates
	MoveWindow(CRect(rectWndRect.TopLeft() + CPoint(2, 344), CSize(456, 261)), TRUE);  // set dialog size

	// Thermometer Bitmap
	m_pLCDBitmap = new CBitmap();
	m_pLCDBitmap->LoadBitmap(IDB_LCD_DISPLAY);

	m_pLCD = new CStatic();
	m_pLCD->Create("", WS_CHILD|WS_VISIBLE|SS_BITMAP,
				   CRect(CPoint(8,8), CSize(435,173)), this);
	m_pLCD->SetBitmap((HBITMAP) *m_pLCDBitmap);

	// Font of the characters in the display
	m_pCharFont = new CFont();
	m_pCharFont->CreatePointFont(145, "Arial"); // or use "Times New Roman"

	m_pBackBrush = new CBrush();
    m_pBackBrush->CreateSolidBrush(RGB(25,19,153)); // dark blue

//	m_pCharFont->CreateFont(30, 20, 0, 0, FW_BOLD, 0, 0, 0, ANSI_CHARSET, OUT_CHARACTER_PRECIS, 
//			CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, TMPF_TRUETYPE | FF_MODERN, "Arial");

	for(int i = 0; i < 48; i++)
	{
		m_apChars[i] = new CStatic();
		m_apChars[i]->Create("", WS_CHILD | WS_VISIBLE | /*WS_BORDER |*/ SS_CENTER,
							CRect(CPoint(58+21*(i%16), 50+30*int(i/16)), CSize(21, 30)), this);
		m_apChars[i]->SetFont(m_pCharFont, false);

//		m_apPorts[i] = new CStatic();
//		m_apPorts[i]->Create("00h", WS_CHILD | WS_VISIBLE,
//							CRect(CPoint(20+32*(i%10), 202+24*int(i/10)), CSize(27, 14)), this);
//		m_apPorts[i]->SetFont(m_pPortFont, false);
	}

	m_pButtonFont = new CFont();
	m_pButtonFont->CreatePointFont(80, "Arial");

	// "Clear All" button
	m_pClearAllBtn = new CButton();
	m_pClearAllBtn->Create("Clear All", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
						 CRect(CPoint(350, 188), CSize(88, 28)), this, IDC_CLEAR_ALL);
	m_pClearAllBtn->SetFont(m_pButtonFont, true);
	m_pClearAllBtn->SetFocus(); //default button
}


CASCIILCDDlg::~CASCIILCDDlg()
{
	delete m_pCharFont;
	delete m_pBackBrush;
	delete m_pButtonFont;
	delete m_pClearAllBtn;

	for(int i = 0; i < 48; i++)
	{
		delete m_apChars[i];
//		delete m_apPorts[i];
	}
	
}


// OnCtlColor() is called when a child control is about to be drawn
HBRUSH CASCIILCDDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	int i;
	
	if (nCtlColor == CTLCOLOR_STATIC) // only done for static controls
		for (i = 0; i < 48; i++)
			if(m_apChars[i] == pWnd)
			{
				COLORREF rgbText = ::GetNearestColor(pDC->m_hDC, 0xFFFFFFFF); // black

				pDC->SetTextColor(rgbText); // change text color
				//	pDC->SetBkColor(rgbBk);
				pDC->SetBkMode(TRANSPARENT);

				return (HBRUSH)*m_pBackBrush; // update brush
				//	return (HBRUSH) ::GetStockObject(HOLLOW_BRUSH); // transparent brush
			}

	return CWnd::OnCtlColor(pDC, pWnd, nCtlColor);

}


// CASCIILCDDlg message handlers

void CASCIILCDDlg::OnClearAll()
{
	// this is a special case where we write to an Interface Register 
	// since this is supposed to be an output device
	for(int i = 0; i < 48; i++)
		m_apRegisters[i]->setValue(0x0);

	RequestInterrupt(); // force sending new values to the Interface Registers

	updateGUI(); // redraw all LEDs
}


void CASCIILCDDlg::updateGUI()
{
	char cValue;

	for(int i = 0; i < 48; i++)
	{
		cValue = (char) m_apRegisters[i]->getValue();
		m_apChars[i]->SetWindowText(CString(cValue));
//		sprintf(buffer, "%2.2Xh", cValue);
//		m_apPorts[i]->SetWindowText(buffer);
	}
}

