
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

#include "HardwareDeviceDlg.h"

// ThermometerDlg.h : header file
//

// CThermometerDlg dialog
//
// An Input device representing a thermometer connected to 
// an 8-bit interface register. 
// The value returned is 0x00 if temperature is -40 C and
// the value returned is 0xA0 if temperature is +120 C
//

class CThermometerDlg : public CHardwareDeviceDlg
{
private:
	InterfaceRegister *m_pTempValue;

	CBitmap *m_pThermometerBitmap;
	CStatic *m_pThermometer;
	CStatic *m_pMercuryBar;

	CSliderCtrl *m_pTempSlider;

	CFont *m_pFont;
	CStatic *m_pTempValueLabel;

// Dialog Data
	enum {IDC_TEMP_SLIDER = 4000};

// Construction
public:
	CThermometerDlg(CWnd* pParent = NULL);   // standard constructor
	~CThermometerDlg();

// Implementation
	virtual void updateGUI();
	BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);

	DECLARE_MESSAGE_MAP()
};

