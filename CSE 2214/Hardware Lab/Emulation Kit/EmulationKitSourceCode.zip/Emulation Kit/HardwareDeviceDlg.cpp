
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// HardwareDeviceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Emulation Kit.h"
#include "HardwareDeviceDlg.h"
#include "Constants.h"
#include "resource.h"

// CHardwareDeviceDlg dialog

IMPLEMENT_DYNAMIC(CHardwareDeviceDlg, CDialog)

CHardwareDeviceDlg::CHardwareDeviceDlg(CWnd* pParent, 
				short int nDeviceType, bool bWordRegisters, 
				unsigned short int usnStartingAddress, int nNumOfRegisters)
	: CDialog(IDD_HARDWARE_DEVICE, pParent)
{
	if(usnStartingAddress < MIN_IO_ADDRESS || (usnStartingAddress + nNumOfRegisters - 1) > MAX_IO_ADDRESS)
		MessageBox("Assigned I/O address(es) are not in the valid range!\n The device might not work properly");

	m_nDeviceType = nDeviceType;
	m_bInterruptRequested = false;

	m_nNumOfRegisters = nNumOfRegisters; 
	m_apkRegisters = new InterfaceRegister*[m_nNumOfRegisters];

	// create Interface Registers
	for(int i = 0; i < m_nNumOfRegisters; i++)
		m_apkRegisters[i] = new InterfaceRegister(bWordRegisters, usnStartingAddress + (bWordRegisters? 2*i : i));  

	CDialog::Create(IDD_HARDWARE_DEVICE, pParent);
}

CHardwareDeviceDlg::~CHardwareDeviceDlg()
{
}


int CHardwareDeviceDlg::getDeviceType()
{
	return m_nDeviceType;
}


void CHardwareDeviceDlg::RequestInterrupt()
{
	// device wants to write Interface Register contents to Emu8086
	m_bInterruptRequested = true;
}


void CHardwareDeviceDlg::ResetInterruptRequest()
{
	// device finished writing Interface Register contents to Emu8086
	m_bInterruptRequested = false;
}


bool CHardwareDeviceDlg::InterruptIsRequested()
{
	return m_bInterruptRequested;
}


InterfaceRegister **CHardwareDeviceDlg::getInterfaceRegisters()
{
	return m_apkRegisters;
}


int CHardwareDeviceDlg::getNumOfRegisters()
{
	return m_nNumOfRegisters;
}

BEGIN_MESSAGE_MAP(CHardwareDeviceDlg, CDialog)
END_MESSAGE_MAP()

// CHardwareDeviceDlg message handlers
