
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// KeyboardDlg.cpp : implementation file
//

#include "stdafx.h"
#include "KeyboardDlg.h"
#include "InterfaceRegister.h"
#include "Constants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CKeyboardDlg dialog

BEGIN_MESSAGE_MAP(CKeyboardDlg, CDialog)
ON_BN_CLICKED(IDC_CHANGE_LABELS, OnChangeLabels)
ON_BN_CLICKED(IDC_CLEAR_BUFFER, OnClearBuffer)
ON_BN_CLICKED(5000, OnKeyPressed)
ON_BN_CLICKED(5001, OnKeyPressed)
ON_BN_CLICKED(5002, OnKeyPressed)
ON_BN_CLICKED(5003, OnKeyPressed)
ON_BN_CLICKED(5004, OnKeyPressed)
ON_BN_CLICKED(5005, OnKeyPressed)
ON_BN_CLICKED(5006, OnKeyPressed)
ON_BN_CLICKED(5007, OnKeyPressed)
ON_BN_CLICKED(5008, OnKeyPressed)
ON_BN_CLICKED(5009, OnKeyPressed)
ON_BN_CLICKED(5010, OnKeyPressed)
ON_BN_CLICKED(5011, OnKeyPressed)
ON_BN_CLICKED(5012, OnKeyPressed)
ON_BN_CLICKED(5013, OnKeyPressed)
ON_BN_CLICKED(5014, OnKeyPressed)
ON_BN_CLICKED(5015, OnKeyPressed)
ON_BN_CLICKED(5016, OnKeyPressed)
ON_BN_CLICKED(5017, OnKeyPressed)
ON_BN_CLICKED(5018, OnKeyPressed)
ON_BN_CLICKED(5019, OnKeyPressed)
ON_BN_CLICKED(5020, OnKeyPressed)
ON_BN_CLICKED(5021, OnKeyPressed)
ON_BN_CLICKED(5022, OnKeyPressed)
ON_BN_CLICKED(5023, OnKeyPressed)
END_MESSAGE_MAP()


CKeyboardDlg::CKeyboardDlg(CWnd* pParent /*=NULL*/)
	: CHardwareDeviceDlg(pParent, INPUT_DEVICE, EIGHT_BIT_REGISTER, KEYBOARD_ADDRESS, 2)
{
	m_pKeyValue = (CHardwareDeviceDlg::getInterfaceRegisters())[0]; // 2 registers
	m_pBufferFull = (CHardwareDeviceDlg::getInterfaceRegisters())[1];

	m_pKeyValue->setValue(0); // initialize everything to zero
	m_pBufferFull->setValue(0);

	// dialog text
	SetWindowText("Keyboard Input (2082h)");

	// dialog size
	CRect rectWndRect;
	pParent->GetWindowRect(&rectWndRect); // get client window coordinates
	MoveWindow(CRect(rectWndRect.TopLeft() + CPoint(662, 402), CSize(272, 250)), TRUE);  // set dialog size

	// dialog font (to be used in all controls)
	m_pFont = new CFont();
	m_pFont->CreatePointFont(80, "Arial"); // or use "MS Shell Dlg" (80)

	// first set of labels (initial set)
	char *pcLabels[24] = {"&0", "&1", "&2", "&3", "&4", 
						  "&5", "&6", "&7", "&8", "&9", 
						  "&A", "&B", "&C", "&D", "&E", "&F", 
						  "A1", "A2", "A3", "A4", 
						  "A5", "A6", "A7", "A8"};

	for(int i = 0; i < 24; i++)
	{
		m_apKeys[i] = new CButton();
		m_apKeys[i]->Create(pcLabels[i], WS_CHILD | WS_VISIBLE,
							CRect(CPoint(15+30*(i%4), 15+30*int(i/4)), CSize(29, 29)), this, 5000+i);
		m_apKeys[i]->SetFont(m_pFont, true);
	}

	nLebelsUsed = 1; // used first set of labels (can be changed)

	m_pKeyValueLabel = new CStatic();
	m_pKeyValueLabel->Create("Buffer:\n0x00", WS_CHILD | WS_VISIBLE | SS_LEFT,
							CRect(CPoint(170, 90), CSize(120, 35)), this);
	m_pKeyValueLabel->SetFont(m_pFont, true);

	m_pBufferFullLabel = new CStatic();
	m_pBufferFullLabel->Create("Buffer Full:\n00000000", WS_CHILD | WS_VISIBLE | SS_LEFT,
							CRect(CPoint(170, 130), CSize(120, 35)), this);
	m_pBufferFullLabel->SetFont(m_pFont, true);

	// "Change Labels" and "Clear Buffer" button
	m_pClearBufferBtn = new CButton();
	m_pClearBufferBtn->Create("Clear Buffer", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
						 CRect(CPoint(160, 15), CSize(88, 28)), this, IDC_CLEAR_BUFFER);
	m_pClearBufferBtn->SetFont(m_pFont, true);
	m_pClearBufferBtn->SetFocus(); //default button

	m_pChangeLabelsBtn = new CButton();
	m_pChangeLabelsBtn->Create("New Labels", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
						 CRect(CPoint(160, 45), CSize(88, 28)), this, IDC_CHANGE_LABELS);
	m_pChangeLabelsBtn->SetFont(m_pFont, true);
}


CKeyboardDlg::~CKeyboardDlg()
{
	for(int i = 0; i < 24; i++)
		delete m_apKeys[i];

	delete m_pFont;
	delete m_pKeyValueLabel;
	delete m_pChangeLabelsBtn;
	delete m_pClearBufferBtn;
}
							 
// CKeyboardDlg message handlers

void CKeyboardDlg::OnChangeLabels()
{
	char *pcLabels1[8] = {"A1", "A2", "A3", "A4",  // first set
						  "A5", "A6", "A7", "A8"};

	char *pcLabels2[8] = {"&+", "&-", "&*", "&/",  // second set
						 "&&", "|", "^", "&="};

	if(nLebelsUsed == 1) // go to second set
	{
		for(int i = 16; i < 24; i++) // change only special characters
			m_apKeys[i]->SetWindowText(pcLabels2[i-16]);
		nLebelsUsed = 2;
	}
	else if(nLebelsUsed == 2) // go to first set
	{
		for(int i = 16; i < 24; i++) // change only special characters
			m_apKeys[i]->SetWindowText(pcLabels1[i-16]);
		nLebelsUsed = 1;
	}
}

void CKeyboardDlg::OnKeyPressed()
{
	// cannot read another key if buffer is full
	if(m_pBufferFull->getValue())
	{
		Beep( 400, 50 ); // beep
		return;
	}

	// buffer is empty (read the pressed key)

	const MSG* message = GetCurrentMessage(); 
	char cKeyValue = char(message->wParam - 5000);
	// message is a button click (message->message == 273)
	// and button ID (message->wParam) is between 5000 and 5023
	
	m_pKeyValue->setValue(cKeyValue); // fill the registers
	m_pBufferFull->setValue(1);

	RequestInterrupt(); // force sending new values to the Interface Registers
	updateGUI();
}


void CKeyboardDlg::OnClearBuffer()
{
	m_pBufferFull->setValue(0);

	RequestInterrupt(); // force sending new values to the Interface Registers
	updateGUI();
}


void CKeyboardDlg::updateGUI()
{
	char buffer[25];

	char cKeyValue = (char) m_pKeyValue->getValue(); // fill the registers
	sprintf(buffer, "Buffer:\n0x%02X", cKeyValue);

	m_pKeyValueLabel->SetWindowText(buffer);

	if(m_pBufferFull->getValue())
		m_pBufferFullLabel->SetWindowText("Buffer Full:\n00000001");
	else
		m_pBufferFullLabel->SetWindowText("Buffer Full:\n00000000");
}


