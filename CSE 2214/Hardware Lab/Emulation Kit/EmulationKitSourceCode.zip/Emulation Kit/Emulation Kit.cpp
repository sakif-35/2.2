
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// Emulation Kit.cpp : Defines the class behaviors for the application 
// (CEmulationKitApp) and for the Help | About Dialog (CAboutDlg).
//

#include "stdafx.h"
#include "Emulation Kit.h"
#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CEmulationKitApp

BEGIN_MESSAGE_MAP(CEmulationKitApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
END_MESSAGE_MAP()


// CEmulationKitApp construction

CEmulationKitApp::CEmulationKitApp()
{
	// add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CEmulationKitApp object

CEmulationKitApp theApp;

// CEmulationKitApp initialization

BOOL CEmulationKitApp::InitInstance()
{
	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need

	// Change the registry key under which our settings are stored
	SetRegistryKey(_T("University of Jordan - Mohammed Hawa"));

	// To create the main window, this code creates a new frame window
	// object and then sets it as the application's main window object
	CMainFrame* pFrame = new CMainFrame;
	if (!pFrame)
		return FALSE;
	m_pMainWnd = pFrame;

	// create and load the frame with its resources
	pFrame->LoadFrame(IDI_SEVENSEGMENT, WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL, NULL);

	// The one and only window has been initialized, so show and update it
	pFrame->ShowWindow(SW_SHOWMAXIMIZED);
	pFrame->UpdateWindow();
	// call DragAcceptFiles only if there's a suffix
	//  In an SDI app, this should occur after ProcessShellCommand
	return TRUE;
}


// CEmulationKitApp message handlers



/////////////////////////////////////////////////////////////////////////////
// CAboutDlg: 
// Implements the "Help | About" dialog. Credits to those who contribute 
// code will be listed here.
//

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnChangeSelection();
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CListBox* pDeviceList = (CListBox*) GetDlgItem(IDC_DEVICE_LIST);
	ASSERT(pDeviceList != NULL);
	CEdit* pCodeContribution = (CEdit*) GetDlgItem(IDC_CODE_CONTRIBUTION);
	ASSERT(pCodeContribution != NULL);

	pDeviceList->InsertString(0,"Architecture and interface to the Emu8086 program, Version 1.75");
	pDeviceList->InsertString(1,"Dot Matrix Display Output, Version 2.0");
	pDeviceList->InsertString(2,"Seven Segment Display Output, Version 2.0");
	pDeviceList->InsertString(3,"ASCII LCD Display Output, Version 2.0");
	pDeviceList->InsertString(4,"LEDs Output, Version 1.5");

	pDeviceList->InsertString(5,"Push Buttons Input, Version 1.5");
	pDeviceList->InsertString(6,"Keyboard Input, Version 1.5");
	pDeviceList->InsertString(7,"Switches Input, Version 1.5");
	pDeviceList->InsertString(8,"Thermometer Input, Version 1.5");
	pDeviceList->InsertString(9,"Pressure Gauge Input, Version 1.2");

	pCodeContribution->SetWindowText("Select one of the above components");

	CDialog::DoDataExchange(pDX);
}

void CAboutDlg::OnChangeSelection()
{
	CListBox* pDeviceList = (CListBox*) GetDlgItem(IDC_DEVICE_LIST);
	ASSERT(pDeviceList != NULL);

	CEdit* pCodeContribution = (CEdit*) GetDlgItem(IDC_CODE_CONTRIBUTION);
	ASSERT(pCodeContribution != NULL);

	int nIndex = pDeviceList->GetCurSel();
	switch(nIndex)
	{
		case 0:
			pCodeContribution->SetWindowText("Version 1.75: Mohammed Hawa, University of Jordan");
			break;
		case 1:
			pCodeContribution->SetWindowText("Version 1.0: Nicola Abdoo, University of Jordan\r\nVersion 2.0: Mohammed Hawa, University of Jordan");
			break;
		case 2:
			pCodeContribution->SetWindowText("Version 1.0: Amer Abu Duhair, University of Jordan\r\nVersion 2.0: Mohammed Hawa, University of Jordan");
			break;
		case 3:
			pCodeContribution->SetWindowText("Version 1.0: Ahmed Abdul Yaman, University of Jordan\r\nVersion 2.0: Mohammed Hawa, University of Jordan");
			break;
		case 4:
			pCodeContribution->SetWindowText("Version 1.5: Mohammed Hawa, University of Jordan");
			break;

		case 5:
			pCodeContribution->SetWindowText("Version 1.5: Mohammed Hawa, University of Jordan");
			break;
		case 6:
			pCodeContribution->SetWindowText("Version 1.5: Mohammed Hawa, University of Jordan");
			break;
		case 7:
			pCodeContribution->SetWindowText("Version 1.0: Husam Al Bakri, University of Jordan\r\nVersion 1.5: Mohammed Hawa, University of Jordan");
			break;
		case 8:
			pCodeContribution->SetWindowText("Version 1.5: Mohammed Hawa, University of Jordan");
			break;
		case 9:
			pCodeContribution->SetWindowText("Version 1.0: Mohanad Al Sayeh, University of Jordan\r\nVersion 1.2: Mohammed Hawa, University of Jordan");
			break;

		default:
			pCodeContribution->SetWindowText("No Selection");
			break;
	}
}


BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	ON_LBN_SELCHANGE(IDC_DEVICE_LIST, OnChangeSelection)
END_MESSAGE_MAP()

// App command to run the dialog
void CEmulationKitApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}



