
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "Emulation Kit.h"
#include "ChildView.h"
#include "Constants.h"

#include "DotMatrixDlg.h"
#include "SevenSegmentDlg.h"
#include "ASCIILCDDlg.h"
#include "LEDsDlg.h"

#include "PushButtonsDlg.h"
#include "KeyboardDlg.h"
#include "SwitchesDlg.h"
#include "ThermometerDlg.h"
#include "PressureDlg.h"

#include "InterfaceRegister.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView
BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_COMMAND(ID_DEVICES_DOT_MATRIX, OnDevicesDotMatrix)
	ON_COMMAND(ID_DEVICES_SEVEN_SEGMENT, OnDevicesSevenSegment)
	ON_COMMAND(ID_DEVICES_ASCII_LCD, OnDevicesASCIILCD)
	ON_COMMAND(ID_DEVICES_LED, OnDevicesLED)
	ON_COMMAND(ID_DEVICES_PUSH_BUTTONS, OnDevicesPushButtons)
	ON_COMMAND(ID_DEVICES_KEYBOARD, OnDevicesKeyboard)
	ON_COMMAND(ID_DEVICES_SWITCHES, OnDevicesSwitches)
	ON_COMMAND(ID_DEVICES_THERMOMETER, OnDevicesThermometer)
	ON_COMMAND(ID_DEVICES_PRESSURe, OnDevicesPressure)
END_MESSAGE_MAP()


CChildView::CChildView()
{
	int i;

	m_bTimerStarted = false;
	m_unTimerID = 106;
	m_bInitialChecksDone = false;

	for (i = 0; i < MAX_NUM_OF_DEVICES; i++)
		m_apDeviceDlg[i] = NULL; // none of the devices is created yet!

	for (i = 0; i < MAX_NUM_OF_PORTS; i++)
		m_aucEmulatorMemory[i] = 0; // initialize memory

	// Read the file "Emulation Kit.ini" for information about the 
	// Emu8086 I/O port file (default value is C:\emu8086.io)
	//
	// The .ini file structure is as follows:
	//
	// [Emu8086]
	// EmuPort=C:\emu8086.io

	// construct the 8086 Emulator I/O file name 
//	GetTempPath (499,m_strFileName);
//	const char buffer[] = "EmuPort.io";
//	strcat(m_strFileName, buffer);
	
	const char buffer[] = "C:\\emu8086.io";
	strcpy(m_strFileName, buffer);

}

CChildView::~CChildView()
{
	if(m_bTimerStarted) 
	{
		this->KillTimer(m_unTimerID);
		m_bTimerStarted = false; // in case pending timer message ar
	}

//	delete m_pTimerInterval;

	for (int i = 0; i < MAX_NUM_OF_DEVICES; i++)  // destruct any modeless dialogs remaining
		if(m_apDeviceDlg[i] != NULL)
			delete m_apDeviceDlg[i];
}



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}



void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	if(!m_bTimerStarted)
	{
		// show all input/output devices available
		OnDevicesDotMatrix();
		OnDevicesSevenSegment();
		OnDevicesASCIILCD();
		OnDevicesLED();

		OnDevicesPushButtons();
		OnDevicesKeyboard();
		OnDevicesSwitches();
		OnDevicesThermometer();
		OnDevicesPressure();

		m_unTimerInterval = INITIAL_TIMER_INTERVAL;
		if ( this->SetTimer(m_unTimerID, m_unTimerInterval, NULL) == 0 )
			MessageBox("Failed to create an appropriate timer! The program might not work properly.", "Fatal Error!");

		m_bTimerStarted = true;	// allow timer processing
	}

	// Do not call CWnd::OnPaint() for painting messages
}


void CChildView::SetTimerInterval(UINT unDelay)
{
	if(unDelay != m_unTimerInterval)
	{
		m_unTimerInterval = unDelay;
		this->KillTimer(m_unTimerID);
		if ( this->SetTimer(m_unTimerID, m_unTimerInterval, NULL) == 0 )
			MessageBox("Failed to create an appropriate timer! The program might not work properly.", "Fatal Error!");
	}
}


void CChildView::OnTimer(UINT nIDEvent)
{
	int i, j;
	CFile kIOFile;
	CFileStatus kStatus;
	CFileException e;

	InterfaceRegister **apAllIntefaceRegisters;
	int nNumOfRegisters;

	bool bNewValueExists;
	bool bUpdateFlag;

	if(nIDEvent != m_unTimerID)	//	do not process this timer event (not ours)
	{
		CWnd ::OnTimer(nIDEvent); // instead process it with the default function
		return;
	}
	
	if(!m_bTimerStarted) // an unexpected event, do not process
		return;

	if(!m_bInitialChecksDone) 
	{
		// first time to run I/O Emulation Kit, make initial checks on I/O File
		m_bInitialChecksDone = true;

		// test the existance of Emu8086 and its I/O File and report any problems
		if( !CFile::GetStatus( m_strFileName, kStatus ) )   // static function
		{
			this->KillTimer(m_unTimerID); // having unexpected problems! don't access the file again!
			// don't reset the m_bTimerStarted flag since this will enable the timer again in OnPaint()

			if (MessageBox("Emu8086 I/O file could not be accessed!\n\n Either Emu8086 is not installed properly, or the file \"C:\\emu8086.io\"\n has been accidentally deleted. This program might not work properly.    \n Continue Anyway?" , "Fatal Error", MB_APPLMODAL | MB_ICONSTOP | MB_YESNO) == IDNO)
                (theApp.GetMainWnd())->SendMessage(WM_CLOSE); // quit application
			else
				return; // continue without the timer (i.e., without Emu8086 interactions)
		}

		// read the I/O file into memory to override old values with our own register values
		if( !kIOFile.Open(m_strFileName, CFile::modeRead | CFile::shareExclusive, &e) )
			{
			this->KillTimer(m_unTimerID); // having unexpected problems! don't access the file again!
			// don't reset the m_bTimerStarted flag since this will enable the timer again in OnPaint()!

			if (MessageBox("Emu8086 I/O file could not be accessed!\n\n Either Emu8086 is not installed properly, or the file \"EmuPort.io\"\n has been accidentally deleted. This program might not work properly.    \n Continue Anyway?" , "Fatal Error", MB_APPLMODAL | MB_ICONSTOP | MB_YESNO) == IDNO)
                (theApp.GetMainWnd())->SendMessage(WM_CLOSE); // quit application
			else
				return; // continue without the timer (i.e., without Emu8086 interactions)
			}

		kIOFile.Close(); // close the file, everything seems fine

		m_kTimeFileWasLastRead = 0; // this will force a read when the normal operations start
	}

	// start normal operations
	// check new values in hardware device registers to send to Emulator I/O file
	bNewValueExists = false;
	
	for(i = 0; i < MAX_NUM_OF_DEVICES; i++)
	{
		// if the dialog exists, read its data
		if(m_apDeviceDlg[i] == NULL)
			continue;

		// device must be an input (or input/output) device to write its value to Emu8086
		// if(m_apDeviceDlg[i]->getDeviceType() == OUTPUT_DEVICE)
		//	continue;

		// check to see if device has new data to send to the Emulator
		if( !m_apDeviceDlg[i]->InterruptIsRequested() )
			continue;

		m_apDeviceDlg[i]->ResetInterruptRequest();
		apAllIntefaceRegisters = m_apDeviceDlg[i]->getInterfaceRegisters();
		nNumOfRegisters = m_apDeviceDlg[i]->getNumOfRegisters();

		for(j = 0; j < nNumOfRegisters; j++)
			if(apAllIntefaceRegisters[j]->writeValueToEmulator(m_aucEmulatorMemory))
				bNewValueExists = true;  // falg to open the Emulator I/O file for updates

		// bNewValueExists is another check to make sure there is new data in the 
		// Interface Registers before we actually open the I/O file for writing
	}

	if(bNewValueExists) // fill Emulator I/O file with data from devices with interrupt requests
	{
		// We want to avoid inducing a read of the I/O Emulator file in the 
		// following code just because we are going to update the I/O ourselves 
		// now. But there is no way out of this since the granularity of the 
		// "Date File Was Last Modified" is 1 second, which means we 
		// cannot guarantee that Emu8086 will write something else to the file
		// in the coming 100 ms.

		if( !kIOFile.Open(m_strFileName, CFile::modeWrite | CFile::shareExclusive, &e) )
			return; // will try to open the file next time
		
		kIOFile.Seek(MIN_IO_ADDRESS, CFile::begin); 
		kIOFile.Write(m_aucEmulatorMemory, MAX_NUM_OF_PORTS); // Write all the bytes at once to the file

		kIOFile.Close(); // close the file
	}


	// read new values into m_aucEmulatorMemory 
	// ONLY if the Emulator I/O file has changed
	if( !CFile::GetStatus( m_strFileName, kStatus ) ) // static function
		return; // will try to open the file next time

	// Check the date and time the file was last modified.
	// Remember that the granularity of the "Date File Was Last Modified" 
	// is 1 second, which means we have to use the less than or equal
	// below instead of just less than.
	if( m_kTimeFileWasLastRead < kStatus.m_mtime ||
	   (m_kTimeFileWasLastRead == kStatus.m_mtime && m_kTimeFileWasLastRead == CTime::GetCurrentTime()) )
	{
		// read the file into memory (to override old values)
		if( !kIOFile.Open(m_strFileName, CFile::modeRead | CFile::shareExclusive, &e) )
			return; // will try to open the file next time

		kIOFile.Seek(MIN_IO_ADDRESS, CFile::begin); 
		kIOFile.Read(m_aucEmulatorMemory, MAX_NUM_OF_PORTS);

		kIOFile.Close(); // close the file
		
		// update hardware registers with new values from I/O files
		for(i = 0; i < MAX_NUM_OF_DEVICES; i++)
		{
			if(m_apDeviceDlg[i] == NULL)
				continue;

			// device must be an output (or input/output) device to read its value from Emu8086
			// if(m_apDeviceDlg[i]->getDeviceType() == INPUT_DEVICE)
			//	continue;

			bUpdateFlag = false;

			// if the dialog exists, read its data
			apAllIntefaceRegisters = m_apDeviceDlg[i]->getInterfaceRegisters();
			nNumOfRegisters = m_apDeviceDlg[i]->getNumOfRegisters();

			for(j = 0; j < nNumOfRegisters; j++) // fill registers with data from memory
				if(apAllIntefaceRegisters[j]->readValueFromEmulator(m_aucEmulatorMemory))
					bUpdateFlag = true;

			if(bUpdateFlag)
				m_apDeviceDlg[i]->updateGUI(); // only update for new register values
		}

		// we read the file at this time (time file was last modified)
		m_kTimeFileWasLastRead = kStatus.m_mtime;
	}

	CWnd::OnTimer(nIDEvent);


//char* pFileName = "test.dat";
//TRY
//{
//   CFile f( pFileName, CFile::modeCreate | CFile::modeWrite );
//}
//CATCH( CFileException, e )
//{
   //#ifdef _DEBUG
    //  afxDump << "File could not be opened " << e->m_cause << "\n";
   //#endif
//}
//END_CATCH
}

void CChildView::OnDevicesDotMatrix()
{
	const int nDeviceIndex = 0;

	ASSERT(nDeviceIndex < MAX_NUM_OF_DEVICES);

	if (m_apDeviceDlg[nDeviceIndex] == NULL) 
		m_apDeviceDlg[nDeviceIndex] = new CDotMatrixDlg(this); // first time, create the dialog

	m_apDeviceDlg[nDeviceIndex]->ShowWindow(SW_SHOW); // whether dialog exists or is created, show window
}

void CChildView::OnDevicesSevenSegment()
{
	const int nDeviceIndex = 1;

	ASSERT(nDeviceIndex < MAX_NUM_OF_DEVICES);

	if (m_apDeviceDlg[nDeviceIndex] == NULL) 
		m_apDeviceDlg[nDeviceIndex] = new CSevenSegmentDlg(this); // first time, create the dialog

	m_apDeviceDlg[nDeviceIndex]->ShowWindow(SW_SHOW); // whether dialog exists or is created, show window
}

void CChildView::OnDevicesASCIILCD()
{
	const int nDeviceIndex = 2;

	ASSERT(nDeviceIndex < MAX_NUM_OF_DEVICES);

	if (m_apDeviceDlg[nDeviceIndex] == NULL) 
		m_apDeviceDlg[nDeviceIndex] = new CASCIILCDDlg(this); // first time, create the dialog

	m_apDeviceDlg[nDeviceIndex]->ShowWindow(SW_SHOW); // whether dialog exists or is created, show window
}

void CChildView::OnDevicesLED()
{
	const int nDeviceIndex = 3;

	ASSERT(nDeviceIndex < MAX_NUM_OF_DEVICES);

	if (m_apDeviceDlg[nDeviceIndex] == NULL) 
		m_apDeviceDlg[nDeviceIndex] = new CLEDsDlg(this); // first time, create the dialog

	m_apDeviceDlg[nDeviceIndex]->ShowWindow(SW_SHOW); // whether dialog exists or is created, show window
}

void CChildView::OnDevicesPushButtons()
{
	const int nDeviceIndex = 4;

	ASSERT(nDeviceIndex < MAX_NUM_OF_DEVICES);

	if (m_apDeviceDlg[nDeviceIndex] == NULL) 
		m_apDeviceDlg[nDeviceIndex] = new CPushButtonsDlg(this); // first time, create the dialog

	m_apDeviceDlg[nDeviceIndex]->ShowWindow(SW_SHOW); // whether dialog exists or is created, show window
}

void CChildView::OnDevicesKeyboard()
{
	const int nDeviceIndex = 5;

	ASSERT(nDeviceIndex < MAX_NUM_OF_DEVICES);

	if (m_apDeviceDlg[nDeviceIndex] == NULL) 
		m_apDeviceDlg[nDeviceIndex] = new CKeyboardDlg(this); // first time, create the dialog

	m_apDeviceDlg[nDeviceIndex]->ShowWindow(SW_SHOW); // whether dialog exists or is created, show window
}


void CChildView::OnDevicesSwitches()
{
	const int nDeviceIndex = 6;

	ASSERT(nDeviceIndex < MAX_NUM_OF_DEVICES);

	if (m_apDeviceDlg[nDeviceIndex] == NULL) 
		m_apDeviceDlg[nDeviceIndex] = new CSwitchesDlg(this); // first time, create the dialog

	m_apDeviceDlg[nDeviceIndex]->ShowWindow(SW_SHOW); // whether dialog exists or is created, show window
}



void CChildView::OnDevicesThermometer()
{
	const int nDeviceIndex = 7;

	ASSERT(nDeviceIndex < MAX_NUM_OF_DEVICES);

	if (m_apDeviceDlg[nDeviceIndex] == NULL) 
		m_apDeviceDlg[nDeviceIndex] = new CThermometerDlg(this); // first time, create the dialog

	m_apDeviceDlg[nDeviceIndex]->ShowWindow(SW_SHOW); // whether dialog exists or is created, show window
}

void CChildView::OnDevicesPressure()
{
	const int nDeviceIndex = 8;

	ASSERT(nDeviceIndex < MAX_NUM_OF_DEVICES);

	if (m_apDeviceDlg[nDeviceIndex] == NULL) 
		m_apDeviceDlg[nDeviceIndex] = new CPressureDlg(this); // first time, create the dialog

	m_apDeviceDlg[nDeviceIndex]->ShowWindow(SW_SHOW); // whether dialog exists or is created, show window
}
