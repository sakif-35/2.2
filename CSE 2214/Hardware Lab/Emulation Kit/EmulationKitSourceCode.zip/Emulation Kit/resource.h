//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Emulation Kit.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_HARDWAREDEVICEDLG           103
#define IDD_DOT_MATRIX_DEVICE           103
#define IDD_HARDWARE_DEVICE             103
#define IDR_MAINFRAME                   128
#define IDI_SEVENSEGMENT                128
#define IDR_EmulationKitTYPE            129
#define IDI_EMU8086                     130
#define IDB_DOTMATRIX_ON                133
#define IDB_DOTMATRIX_OFF               134
#define IDB_DOTMATRIX_ON_BIG            135
#define IDB_DOTMATRIX_OFF_BIG           136
#define IDB_DOTMATRIX_FRAME             137
#define IDB_SEVENSEGMENT_DOT_OFF        138
#define IDB_SEVENSEGMENT_DOT_ON         139
#define IDB_SEVENSEGMENT_DOWN_OFF       140
#define IDB_SEVENSEGMENT_HOR_OFF        140
#define IDB_SEVENSEGMENT_DOWN_ON        141
#define IDB_SEVENSEGMENT_LEFT_ON        142
#define IDB_SEVENSEGMENT_LEFT_OFF       143
#define IDB_SEVENSEGMENT_VER_OFF        143
#define IDB_SEVENSEGMENT_MIDDLE_ON      145
#define IDB_PRESSURE                    146
#define IDB_SEVENSEGMENT_UP_ON          149
#define IDB_SEVENSEGMENT_RIGHT_ON       150
#define IDB_SWITCH_OFF                  152
#define IDB_SWITCH_ON                   153
#define IDB_LED_OFF_RED                 154
#define IDB_LED_OFF                     155
#define IDB_LED_ON_RED                  156
#define IDB_LCD_DISPLAY                 164
#define IDB_LED_ON_YELLOW               165
#define IDB_LED_ON_GREEN                166
#define IDB_THERMOMETER                 169
#define IDB_DOTMATRIX_ROWS              170
#define IDB_DOTMATRIX_COLUMNS           171
#define IDB_LILIES                      172
#define IDI_MAINFRAME                   175
#define IDB_CHIPS                       176
#define IDC_REGISTER_VALUE              1000
#define IDC_DELAY_SLIDER                1007
#define IDC_EDIT_LABELS                 1010
#define IDC_VALUE                       1012
#define IDC_DEVICE_LIST                 1025
#define IDC_CODE_CONTRIBUTION           1027
#define IDC_DELAY_VALUE                 1028
#define ID_DEVICES_ONE_BUTTON           32771
#define ID_DEVICES_DOT_MATRIX           32773
#define ID_DEVICES_SEVEN_SEGMENT        32776
#define ID_Menu                         32777
#define ID_DEVICES_KEYBOARD             32779
#define ID_VIRTUALDEVICES_SEPARATOR     32780
#define ID_DEVICES_PUSH_BUTTONS         32783
#define ID_DEVICES_SWITCHES             32785
#define ID_DEVICES_LED                  32787
#define ID_DEVICES_ASCII_LCD            32789
#define ID_DEVICES_THERMOMETER          32791
#define ID_DEVICES_PRESSURe             32793

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        177
#define _APS_NEXT_COMMAND_VALUE         32794
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
