
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// DotMatrixDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DotMatrixDlg.h"
#include "InterfaceRegister.h"
#include "Constants.h"
#include "resource.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDotMatrixDlg dialog

BEGIN_MESSAGE_MAP(CDotMatrixDlg, CDialog)
ON_BN_CLICKED(IDC_CLEAR_ALL, OnClearAll)
ON_BN_CLICKED(IDC_SET_ALL, OnSetAll)
END_MESSAGE_MAP()


CDotMatrixDlg::CDotMatrixDlg(CWnd* pParent /*=NULL*/)
	: CHardwareDeviceDlg(pParent, OUTPUT_DEVICE, EIGHT_BIT_REGISTER, DOT_MATRIX_ADDRESS, 8*5)
{
	char buffer[20];

	m_apRegisters = CHardwareDeviceDlg::getInterfaceRegisters(); // 8*5 = 40 registers

	// dialog text
	SetWindowText("Dot Matrix Display Output (2000h ... 2027h)");

	// dialog size
	CRect rectWndRect;
	pParent->GetWindowRect(&rectWndRect); // get client window coordinates
	MoveWindow(CRect(rectWndRect.TopLeft() + CPoint(2, 2), CSize(660, 178)), TRUE);  // set dialog size

	// dialog font (to be used in all controls)
	m_pFont = new CFont();
	m_pFont->CreatePointFont(80, "Arial"); // or use "MS Shell Dlg" (80)

	m_pRowsLabelBitmap = new CBitmap();
	m_pRowsLabelBitmap->LoadBitmap(IDB_DOTMATRIX_ROWS);

	m_pRowsLabel = new CStatic();
	m_pRowsLabel->Create("", WS_CHILD|WS_VISIBLE|SS_BITMAP,
						 CRect(CPoint(8,24), CSize(8,84)), this);
	m_pRowsLabel->SetBitmap((HBITMAP) *m_pRowsLabelBitmap);

	m_pColumnsLabelBitmap = new CBitmap();
	m_pColumnsLabelBitmap->LoadBitmap(IDB_DOTMATRIX_COLUMNS);

	m_pColumnsLabel = new CStatic();
	m_pColumnsLabel->Create("", WS_CHILD|WS_VISIBLE|SS_BITMAP,
							CRect(CPoint(23,11), CSize(57,10)), this);
	m_pColumnsLabel->SetBitmap((HBITMAP) *m_pColumnsLabelBitmap);

	// dot matrix displays and their addresses in static
	for(int i = 0; i < 8; i++)
	{
		m_apDisplays[i] = new DotMatrixDisplay(this, &CPoint(20 + i*65, 25));

		sprintf(buffer, "%4.4X...%2.2Xh", DOT_MATRIX_ADDRESS + i*5, DOT_MATRIX_ADDRESS + i*5 + 4 - 0x2000);
		m_apAddresses[i] = new CStatic();
		m_apAddresses[i]->Create(buffer, WS_CHILD | WS_VISIBLE | SS_CENTER,
								 CRect(CPoint(18 + i*65, 115), CSize(65, 14)), this);
		m_apAddresses[i]->SetFont(m_pFont, true);
	}

	m_pAddressLabel = new CStatic();
	m_pAddressLabel->Create("<< I/O Address", WS_CHILD | WS_VISIBLE | SS_CENTER,
							CRect(CPoint(545, 114), CSize(92, 28)), this);
	m_pAddressLabel->SetFont(m_pFont, true);


	// "Clear All" and "Set All" buttons
	m_pClearAllBtn = new CButton();
	m_pClearAllBtn->Create("Clear All", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
						 CRect(CPoint(550, 14), CSize(88, 28)), this, IDC_CLEAR_ALL);
	m_pClearAllBtn->SetFont(m_pFont, true);
	m_pClearAllBtn->SetFocus(); //default button

	m_pSetAllBtn = new CButton();
	m_pSetAllBtn->Create("Set All", WS_CHILD | WS_VISIBLE,
					  CRect(CPoint(550, 46), CSize(88, 28)), this, IDC_SET_ALL);
	m_pSetAllBtn->SetFont(m_pFont, true);
}


CDotMatrixDlg::~CDotMatrixDlg()
{
	delete m_pFont;

	delete m_pRowsLabel;
	delete m_pColumnsLabel;
	delete m_pRowsLabelBitmap;
	delete m_pColumnsLabelBitmap;

	for(int i = 0; i < 8; i++)
	{
		delete m_apDisplays[i];
		delete m_apAddresses[i];
	}
	delete m_pAddressLabel;

	delete m_pClearAllBtn;
	delete m_pSetAllBtn;
}

// CDotMatrixDlg message handlers

void CDotMatrixDlg::OnClearAll()
{
	// this is a special case where we write to an Interface Register 
	// since this is supposed to be an output device
	for(int i = 0; i < 40; i++) // 8*5 = 40 registers
		m_apRegisters[i]->setValue(0);

	RequestInterrupt(); // force sending new values to the Interface Registers

	updateGUI(); // redraw all DOT MATRIX digits
}


void CDotMatrixDlg::OnSetAll()
{
	// this is a special case where we write to an Interface Register 
	// since this is supposed to be an output device
	for(int i = 0; i < 40; i++) // 8*5 = 40 registers
		m_apRegisters[i]->setValue(0x7F);

	RequestInterrupt(); // force sending new values to the Interface Registers

	updateGUI(); // redraw all DOT MATRIX digits
}


void CDotMatrixDlg::updateGUI()
{
	int i, j;

	for(i = 0; i < 8; i++)
		for(j = 0; j < 5; j++)
			m_apDisplays[i]->DrawColumn(j, (unsigned char) m_apRegisters[i*5+j]->getValue());
}

////////////////////////////////////////////////////////////////////////////
//

DotMatrixDisplay::DotMatrixDisplay(CWnd* pParentWnd, CPoint *pStartingPos)
{
	int i, j;

	 // initialize all LEDs to OFF
	for(j = 0; j < 5; j++)
        m_ucColumns[j] = 0;

	// create the frame for the DOT MATRIX just once (at the beginning)
	m_pFrameBitmap = new CBitmap();
	m_pFrameBitmap->LoadBitmap(IDB_DOTMATRIX_FRAME);

	m_pFrame = new CStatic();
	m_pFrame->Create("", WS_CHILD|WS_VISIBLE|SS_BITMAP,
					 CRect(CPoint(-2, -2) + *pStartingPos, CSize(60,84)), pParentWnd);
	m_pFrame->SetBitmap((HBITMAP) *m_pFrameBitmap); // HBITMAP is an operator


	// prepare bitmaps
	m_pDotOFF = new CBitmap();
	m_pDotOFF ->LoadBitmap(IDB_DOTMATRIX_OFF_BIG);
	m_pDotON = new CBitmap();
	m_pDotON->LoadBitmap(IDB_DOTMATRIX_ON_BIG);

	// create the dots
	for(i = 0; i < 35; i++)
		m_pDots[i] = new CStatic();
	
	for(i = 0 ; i < 7; i++) // 7 rows
		for (j = 0; j < 5; j++)	// 5 columns
			{
			m_pDots[i*5+j]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_CENTERIMAGE,
									CRect(CPoint(12*j, 12*i) + *pStartingPos, CSize(12, 12)), pParentWnd);

			m_pDots[i*5+j]->SetBitmap((HBITMAP) *m_pDotOFF);
			}
}

DotMatrixDisplay::~DotMatrixDisplay()
{
	delete m_pFrameBitmap;
	delete m_pFrame;

	delete m_pDotOFF;
	delete m_pDotON;

	for(int i = 0; i < 35; i++)
		delete m_pDots[i];
}


// Each 8 bit interface register is considered as follows:
// bits =	  7 6 5 4 3 2 1 0
// unused --> X 7 6 5 4 3 2 1 <-- 7 rows 

// The row bit must be 1 for the LED to be ON.

void DotMatrixDisplay::DrawColumn(int nIndex, unsigned char ucColumnVal)
{
	if( nIndex < 0 || nIndex >= 5)
		return;	// range of columns is 0 to 4 (5 columns)

	if( (m_ucColumns[nIndex] & 0x7F) == (ucColumnVal & 0x7F) )
		return; // nothing changed

	// set new value of the column and redraw it
	m_ucColumns[nIndex] = (ucColumnVal & 0x7F);

	// draw the column
	for(int i = 0 ; i < 7; i++)
		if ( ((m_ucColumns[nIndex] >> i) & 0x01) == 1 ) // test row bits
			m_pDots[i*5+nIndex]->SetBitmap((HBITMAP) *m_pDotON);
		else
			m_pDots[i*5+nIndex]->SetBitmap((HBITMAP) *m_pDotOFF);
}

