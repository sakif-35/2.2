
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

#include "HardwareDeviceDlg.h"

// LEDsDlg.h : header file
//

// CLEDsDlg dialog
//
// This is a group of 8 differently colored LEDs (red, yello, green)
// It is connected to an 8 bit interface register, each one bit 
// must be 1 for the corresponding LED to be ON.

class CLEDsDlg : public CHardwareDeviceDlg
{
private:
	InterfaceRegister *m_pValue;

	CBitmap	*m_pLEDOFF;
	CBitmap	*m_pLEDON[3]; // three different colors

	CStatic* m_apLEDs[8]; // the 8 LEDs of the Display

	CFont *m_pFont;
	CButton *m_pClearAllBtn;
	CButton *m_pSetAllBtn;

// Dialog Data
	enum { IDC_CLEAR_ALL = 5000,
		   IDC_SET_ALL = 5001 };

// Construction
public:
	CLEDsDlg(CWnd* pParent = NULL);   // standard constructor
	~CLEDsDlg();

// Implementation
	virtual void updateGUI();

	afx_msg void OnSetAll();
	afx_msg void OnClearAll();

	DECLARE_MESSAGE_MAP()
};

