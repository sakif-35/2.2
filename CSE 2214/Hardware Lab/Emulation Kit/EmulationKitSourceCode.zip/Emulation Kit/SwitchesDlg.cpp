
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// PushButtonsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SwitchesDlg.h"
#include "InterfaceRegister.h"
#include "Constants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSwitchesDlg dialog

BEGIN_MESSAGE_MAP(CSwitchesDlg, CDialog)
ON_STN_CLICKED(5000, OnSwitchPressed)
ON_STN_CLICKED(5001, OnSwitchPressed)
ON_STN_CLICKED(5002, OnSwitchPressed)
ON_STN_CLICKED(5003, OnSwitchPressed)
ON_STN_CLICKED(5004, OnSwitchPressed)
ON_STN_CLICKED(5005, OnSwitchPressed)
ON_STN_CLICKED(5006, OnSwitchPressed)
ON_STN_CLICKED(5007, OnSwitchPressed)
END_MESSAGE_MAP()


CSwitchesDlg::CSwitchesDlg(CWnd* pParent /*=NULL*/)
	: CHardwareDeviceDlg(pParent, INPUT_DEVICE, EIGHT_BIT_REGISTER, SWITCHES_ADDRESS, 1)
{
	m_pValue = (CHardwareDeviceDlg::getInterfaceRegisters())[0];

	// dialog text
	SetWindowText("Switches Input (2084h)");

	// dialog size
	CRect rectWndRect;
	pParent->GetWindowRect(&rectWndRect); // get client window coordinates
	MoveWindow(CRect(rectWndRect.TopLeft() + CPoint(662, 122), CSize(226, 120)), TRUE);  // set dialog size

	// dialog font (to be used in all controls)
	m_pFont = new CFont();
	m_pFont->CreatePointFont(80, "Arial"); // or use "MS Shell Dlg" (80)

	m_pSwitchOFF = new CBitmap();
	m_pSwitchOFF ->LoadBitmap(IDB_SWITCH_OFF);
	m_pSwitchON = new CBitmap();
	m_pSwitchON->LoadBitmap(IDB_SWITCH_ON);

	for(int i = 0; i < 8; i++)
	{
		// switch 0 is located at the rightmost of the dialog
		m_apSwitches[i] = new CStatic();
		m_apSwitches[i]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP | /*WS_BORDER |*/ SS_NOTIFY, // notify parent of mouse clicks
							CRect(CPoint(180-23*i, 15), CSize(19, 30)), this, 5000+i);
		m_apSwitches[i]->SetBitmap( m_pSwitchOFF->operator HBITMAP() );
	}

	m_pValueLabel = new CStatic();
	m_pValueLabel->Create("00000000", WS_CHILD | WS_VISIBLE | SS_CENTER,
							CRect(CPoint(79, 54), CSize(60, 28)), this);
	m_pValueLabel->SetFont(m_pFont, true);

	updateGUI(); // initial values of switches from Emulator I/O file
}


CSwitchesDlg::~CSwitchesDlg()
{
	delete m_pSwitchOFF;
	delete m_pSwitchON;

	for(int i = 0; i < 8; i++)
		delete m_apSwitches[i];

	delete m_pFont;
	delete m_pValueLabel;
}
							 
// CSwitchesDlg message handlers

void CSwitchesDlg::OnSwitchPressed()
{
	const MSG* message = GetCurrentMessage();
	char cSwitchIndex = char(message->wParam - 5000);
	// message is a switch click (message->message == ???)
	// and button ID (message->wParam) is between 5000 and 5023
	
	unsigned char ucValue = (unsigned char) m_pValue->getValue();

	if(((ucValue >> cSwitchIndex) & 0x0001) == 1)
		ucValue = ucValue ^ (0x0001 << cSwitchIndex);
	else
		ucValue = ucValue ^ (0x0001 << cSwitchIndex);

	m_pValue->setValue(ucValue); // fill the register
	RequestInterrupt(); // force sending new values to the Interface Registers

	updateGUI();
}


void CSwitchesDlg::updateGUI()
{
	unsigned char ucValue = (unsigned char) m_pValue->getValue();

	char buffer[20] = "00000000";

	for(int i = 0; i < 8; i++)
		if(((ucValue >> i) & 0x0001) == 1)
		{
			m_apSwitches[i]->SetBitmap( m_pSwitchON->operator HBITMAP() ); // set switch
			buffer[7 - i] = '1';
		}
		else
		{
			m_apSwitches[i]->SetBitmap( m_pSwitchOFF->operator HBITMAP() ); // reset switch
			buffer[7 - i] = '0';
		}

	m_pValueLabel->SetWindowText(buffer);
}


