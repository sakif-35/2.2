
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

#include "HardwareDeviceDlg.h"

// KeyboardDlg.h : header file
//

// CKeyboardDlg dialog
//
// An Input device consisting of 16 numerical keys (0 - F), and
// 8 special keys (A1 - A8) for a total of 24 keys.
//
// The keyboard is connected to two 8-bit interface registers, 
// the first one contains the code for the pressed key (0 - 24)
// and the second one contains 1 when the key is pressed. When
// the buffer is full, a beep is generated.
//
// Once you read the key code, you have to reset the second register
// to 0 to indicate the buffer is empty.

class CKeyboardDlg : public CHardwareDeviceDlg
{
private:
	InterfaceRegister *m_pKeyValue;
	InterfaceRegister *m_pBufferFull;

	CButton *m_apKeys[24];

	CFont *m_pFont;
	CStatic *m_pKeyValueLabel;
	CStatic *m_pBufferFullLabel;

	CButton *m_pChangeLabelsBtn;
	CButton *m_pClearBufferBtn;
	int nLebelsUsed;

// Dialog Data
	enum {IDC_CHANGE_LABELS = 4000,
	      IDC_CLEAR_BUFFER = 4001};

// Construction
public:
	CKeyboardDlg(CWnd* pParent = NULL);   // standard constructor
	~CKeyboardDlg();

// Implementation
	virtual void updateGUI();

	afx_msg void OnClearBuffer();
	afx_msg void OnChangeLabels();
	afx_msg void OnKeyPressed();

	DECLARE_MESSAGE_MAP()
};

