
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// LEDsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LEDsDlg.h"
#include "InterfaceRegister.h"
#include "Constants.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CLEDsDlg dialog

BEGIN_MESSAGE_MAP(CLEDsDlg, CDialog)
ON_BN_CLICKED(IDC_CLEAR_ALL, OnClearAll)
ON_BN_CLICKED(IDC_SET_ALL, OnSetAll)
END_MESSAGE_MAP()


CLEDsDlg::CLEDsDlg(CWnd* pParent /*=NULL*/)
	: CHardwareDeviceDlg(pParent, OUTPUT_DEVICE, EIGHT_BIT_REGISTER, LED_ADDRESS, 1)
{
	m_pValue = (CHardwareDeviceDlg::getInterfaceRegisters())[0];

	// dialog text
	SetWindowText("LEDs Output (2070h)");

	// dialog size
	CRect rectWndRect;
	pParent->GetWindowRect(&rectWndRect); // get client window coordinates
	MoveWindow(CRect(rectWndRect.TopLeft() + CPoint(662, 2), CSize(320, 120)), TRUE);  // set dialog size

	// dialog font (to be used in all controls)
	m_pFont = new CFont();
	m_pFont->CreatePointFont(80, "Arial"); // or use "MS Shell Dlg" (80)

	m_pLEDOFF = new CBitmap();
	m_pLEDOFF ->LoadBitmap(IDB_LED_OFF);
	m_pLEDON[0] = new CBitmap();
	m_pLEDON[0]->LoadBitmap(IDB_LED_ON_RED);
	m_pLEDON[1] = new CBitmap();
	m_pLEDON[1]->LoadBitmap(IDB_LED_ON_YELLOW);
	m_pLEDON[2] = new CBitmap();
	m_pLEDON[2]->LoadBitmap(IDB_LED_ON_GREEN);

	for(int i = 0; i < 8; i++)
	{
		// LED 0 is located at the rightmost of the dialog
		m_apLEDs[i] = new CStatic();
		m_apLEDs[i]->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP,
							CRect(CPoint(175-23*i, 30), CSize(20, 20)), this);
		m_apLEDs[i]->SetBitmap((HBITMAP) *m_pLEDOFF);
	}

	// "Clear All" and "Set All" buttons
	m_pClearAllBtn = new CButton();
	m_pClearAllBtn->Create("Clear All", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
						 CRect(CPoint(214, 10), CSize(88, 28)), this, IDC_CLEAR_ALL);
	m_pClearAllBtn->SetFont(m_pFont, true);
	m_pClearAllBtn->SetFocus(); //default button

	m_pSetAllBtn = new CButton();
	m_pSetAllBtn->Create("Set All", WS_CHILD | WS_VISIBLE,
					  CRect(CPoint(214, 42), CSize(88, 28)), this, IDC_SET_ALL);
	m_pSetAllBtn->SetFont(m_pFont, true);

	updateGUI(); // show initial value from Emulator I/O file
}


CLEDsDlg::~CLEDsDlg()
{
	delete m_pLEDOFF;

	for (int i = 0; i < 3; i++)
		delete m_pLEDON[i];

	for(int i = 0; i < 8; i++)
		delete m_apLEDs[i];

	delete m_pFont;
	delete m_pClearAllBtn;
	delete m_pSetAllBtn;
}
							 
// CDotMatrixDlg message handlers

void CLEDsDlg::OnClearAll()
{
	// this is a special case where we write to an Interface Register 
	// since this is supposed to be an output device
	m_pValue->setValue(0);
	RequestInterrupt(); // force sending new values to the Interface Registers

	updateGUI(); // redraw all LEDs
}


void CLEDsDlg::OnSetAll()
{
	// this is a special case where we write to an Interface Register 
	// since this is supposed to be an output device
	m_pValue->setValue(0xFF);
	RequestInterrupt(); // force sending new values to the Interface Registers

	updateGUI(); // redraw all LEDs
}


void CLEDsDlg::updateGUI()
{
	unsigned char ucValue = (unsigned char) m_pValue->getValue();

	for(int i = 0; i < 8; i++)
		if ( ((ucValue >> i) & 0x01) == 1 ) // test the bits
		{
			if(m_apLEDs[i]->GetBitmap() == (HBITMAP) *m_pLEDOFF) // LED is OFF
				m_apLEDs[i]->SetBitmap((HBITMAP) *m_pLEDON[i%3]); // LED must be ON
			else
				continue; // do nothing, LED is ON already (avoid flickering)
		}
		else
		{
			if(m_apLEDs[i]->GetBitmap() != (HBITMAP) *m_pLEDOFF) // LED is not OFF
				m_apLEDs[i]->SetBitmap((HBITMAP) *m_pLEDOFF); // LED must be OFF
			else
				continue; // do nothing, LED is OFF already (avoid flickering)
		}
}




