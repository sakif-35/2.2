
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


// KeyboardDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ThermometerDlg.h"
#include "InterfaceRegister.h"
#include "Constants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CKeyboardDlg dialog

BEGIN_MESSAGE_MAP(CThermometerDlg, CDialog)
END_MESSAGE_MAP()


CThermometerDlg::CThermometerDlg(CWnd* pParent /*=NULL*/)
	: CHardwareDeviceDlg(pParent, INPUT_DEVICE, EIGHT_BIT_REGISTER, THERMOMETER_ADDRESS, 1)
{
	m_pTempValue = (CHardwareDeviceDlg::getInterfaceRegisters())[0]; // initial value is zero

	// dialog text
	SetWindowText("Thermometer (2086h)");

	// dialog size
	CRect rectWndRect;
	pParent->GetWindowRect(&rectWndRect); // get client window coordinates
	MoveWindow(CRect(rectWndRect.TopLeft() + CPoint(458, 344), CSize(204, 281)), TRUE);  // set dialog size

	// dialog font (to be used in all controls)
	m_pFont = new CFont();
	m_pFont->CreatePointFont(80, "Arial"); // or use "MS Shell Dlg" (80)

	m_pThermometerBitmap = new CBitmap();
	m_pThermometerBitmap->LoadBitmap(IDB_THERMOMETER);

	m_pThermometer = new CStatic();
	m_pThermometer->Create("", WS_CHILD | WS_VISIBLE | SS_BITMAP,
				   CRect(CPoint(17,12), CSize(435,173)), this);
	m_pThermometer->SetBitmap((HBITMAP) *m_pThermometerBitmap);

	m_pMercuryBar = new CStatic();
	m_pMercuryBar->Create("", WS_CHILD | WS_VISIBLE | SS_WHITERECT,
							CRect(CPoint(30, 19), CSize(9, 0)), this);

	// Temperature Slider
	m_pTempSlider = new CSliderCtrl();
	m_pTempSlider->Create(WS_CHILD | WS_VISIBLE | TBS_VERT | TBS_LEFT | TBS_AUTOTICKS,
						  CRect(CPoint(139, 11), CSize(21, 187)), this, IDC_TEMP_SLIDER);
	// position 0 corresponds to 0xA0 and corresponds to +120 C 
	// position 160 corresponds to 0x00 and corresponds to -40 C 
	m_pTempSlider->SetRange(0, 160, TRUE ); // min, max range values
	m_pTempSlider->SetLineSize(10);   // Up/Down Notifications
	m_pTempSlider->SetPageSize(40);   // PgUp/PgDown Notifications
	m_pTempSlider->SetTicFreq(40);    // Send TBM_SETTICFREQ
	m_pTempSlider->SetPos(160);
	m_pTempSlider->SetFocus();

	m_pTempValueLabel = new CStatic();
	m_pTempValueLabel->Create("Temperature: 0x00  (-40 C)", WS_CHILD | WS_VISIBLE | SS_LEFT,
							CRect(CPoint(16, 215), CSize(180, 28)), this);
	m_pTempValueLabel->SetFont(m_pFont, true);

}


CThermometerDlg::~CThermometerDlg()
{
	delete m_pThermometerBitmap;
	delete m_pThermometer;
	delete m_pMercuryBar;

	delete m_pTempSlider;

	delete m_pFont;
	delete m_pTempValueLabel;
}
							 
// CThermometerDlg message handlers

void CThermometerDlg::updateGUI()
{
// do nothing (this is an input device not an output device)
}

BOOL CThermometerDlg::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	if(wParam == IDC_TEMP_SLIDER)
	{
		int	nPos = m_pTempSlider->GetPos();
		int nTempValue = (160 - nPos) - 40; // in celsius

		// adjust mercury bar
		m_pMercuryBar->MoveWindow(30, 19, 9, int(1.05*nPos), TRUE );

		// update temperature reading
		char buffer[40];
		sprintf(buffer, "Temperature: 0x%02X  (%+d C)", 160 - nPos, nTempValue);
		m_pTempValueLabel->SetWindowText(buffer);

		m_pTempValue->setValue(160 - nPos);

		RequestInterrupt(); // force sending new values to the Interface Registers
	}

	return CWnd::OnNotify(wParam, lParam, pResult);
}

