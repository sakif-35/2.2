
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

/////////////////////////////////////////////////////////////////////////////
// Constants for the I/O Emulation Kit Application
//


// We do not refer to I/O port numbers as such but to I/O addresses 
#define MIN_IO_ADDRESS		8192	//	0x2000
#define MAX_IO_ADDRESS		12287	//	0x2FFF
#define MAX_NUM_OF_PORTS	4096

#define MAX_NUM_OF_DEVICES 			50
#define INITIAL_TIMER_INTERVAL		100	// 100 ms

#define INPUT_DEVICE			0
#define OUTPUT_DEVICE			1
#define INPUT_OUTPUT_DEVICE		2

#define EIGHT_BIT_REGISTER 		false
#define SIXTEEN_BIT_REGISTER 	true

#define DOT_MATRIX_ADDRESS		0x2000 // all the way up to 0x2027 (40 registers)
#define SEVEN_SEGMENT_ADDRESS	0x2030 // all the way up to 0x2037 (8 registers)
#define ASCII_LCD_ADDRESS		0x2040 // all the way up to 0x206F (48 registers)
#define LED_ADDRESS				0x2070 // single address

#define PUSH_BUTTONS_ADDRESS	0x2080 // single address (16-bit register)
#define KEYBOARD_ADDRESS		0x2082 // up to 0x2083 (2 registers)
#define SWITCHES_ADDRESS		0x2084 // single address (8-bit register)
#define THERMOMETER_ADDRESS		0x2086 // single address (8-bit register)
#define PRESSURE_ADDRESS		0x2088 // single address (8-bit register)

#define ONE_BUTTON_ADDRESS		0x20A0 // single address
