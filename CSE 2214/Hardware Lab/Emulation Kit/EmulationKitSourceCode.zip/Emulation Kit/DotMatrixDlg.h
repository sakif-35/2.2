
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


#pragma once

#include "HardwareDeviceDlg.h"

// DotMatrixDlg.h : header file
//

// DotMatrixDisplay
//
// Basic entity for the 7x5 Dot Matrix Display (LMD07057B) -- Type B
//
// In Type B Dot Matrix Display, the Rows are connected to the Anodes (+)
// of the LEDs, while the columns are connected to the Cathode (-).
// Rows are numbered from 1 up to 7 down, while columns are numbered
// 1 left to 5 right.
//
// Each 7x5 Dot Matrix Display is connected to 5 interface regsiters,
// each one of these registers corresponds to one column.
// The first resgiter (least I/O address) corresponds to column 1,
// and the second register to column 2, and so on.

// Each 8 bit interface register is considered as follows:
// bits =	  7 6 5 4 3 2 1 0
// unused --> X 7 6 5 4 3 2 1 <-- 7 rows 

// The row bit must be 1 for the LED to be ON.


class DotMatrixDisplay
{
private:
	unsigned char m_ucColumns[5]; // the 5 columns of the Display

	CBitmap* m_pFrameBitmap;
	CStatic* m_pFrame;

	CBitmap	*m_pDotOFF;
	CBitmap	*m_pDotON;
	CStatic* m_pDots[35]; // the 7x5 dots of the Display

public:
	DotMatrixDisplay(CWnd* pParentWnd, CPoint *pStartingPos);
	~DotMatrixDisplay();

	void DrawColumn(int nIndex, unsigned char ucColumnVal);
};


// CDotMatrixDlg dialog
//
// An Output device consisting of eight Dot Matrix displays. Each display 
// consists of 7x5 dots that could be ON (red) or OFF.
//

class CDotMatrixDlg : public CHardwareDeviceDlg
{
private:
	InterfaceRegister **m_apRegisters; // 8 registers
	DotMatrixDisplay *m_apDisplays[8];

	CFont *m_pFont;

	CBitmap *m_pRowsLabelBitmap;
	CBitmap *m_pColumnsLabelBitmap;
    CStatic *m_pRowsLabel;
    CStatic *m_pColumnsLabel;

	CStatic *m_apAddresses[8];
	CStatic *m_pAddressLabel;

	CButton *m_pClearAllBtn;
	CButton *m_pSetAllBtn;

// Dialog Data
	enum { IDC_CLEAR_ALL = 5000,
		   IDC_SET_ALL = 5001};

// Construction
public:
	CDotMatrixDlg(CWnd* pParent = NULL);   // standard constructor
	~CDotMatrixDlg();

// Implementation
	void updateGUI();

	afx_msg void OnSetAll();
	afx_msg void OnClearAll();

	DECLARE_MESSAGE_MAP()
};

