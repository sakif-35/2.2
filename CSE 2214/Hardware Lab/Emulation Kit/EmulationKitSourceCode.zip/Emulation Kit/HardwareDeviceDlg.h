
// Copyright � 2004-2014 by Mohammed Hawa. All rights reserved.

// THIS SOFTWARE IS PROVIDED ''AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

#pragma once

#include "InterfaceRegister.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CHardwareDeviceDlg dialog
//
// Base class for all the I/O devices to be implemented in the I/O Emulation Kit. 
// Handles the main functions for dealing with Interface Registers and 
// initializing the I/O device. Leaves the updateGUI() function to be 
// implemented by the user.
//


class CHardwareDeviceDlg : public CDialog
{
	DECLARE_DYNAMIC(CHardwareDeviceDlg)

private:
	short int m_nDeviceType;  // TODO if not needed then remove it from class
	bool m_bInterruptRequested;

	InterfaceRegister **m_apkRegisters;
	int m_nNumOfRegisters;


// Construction
public:
	CHardwareDeviceDlg(CWnd* pParent, 
				short int nDeviceType, bool bWordRegisters, 
				unsigned short int usnStartingAddress, int nNumOfRegisters);
	virtual ~CHardwareDeviceDlg();


public:
	int getDeviceType();

	void RequestInterrupt(); // device wants to write Interface Register contents to Emu8086
	void ResetInterruptRequest();
	bool InterruptIsRequested();

	InterfaceRegister **getInterfaceRegisters();
	int getNumOfRegisters();

	virtual void updateGUI() = 0;	// call after Interface Register value changes

	DECLARE_MESSAGE_MAP()
};
